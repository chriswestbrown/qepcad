#ifndef YYSTYPE
#define YYSTYPE int
#endif
#define	VAR	257
#define	PLUS	258
#define	MINUS	259
#define	PROD	260
#define	EXP	261
#define	NUMBER	262
#define	RELOPTOK	263
#define	ZERO	264
#define	ANDTOK	265
#define	ORTOK	266
#define	LEFTP	267
#define	RIGHTP	268
#define	MULTVAR	269
#define	MULTNUM	270
#define	RSYMBP	271
#define	RSYMBN	272
#define	TRUETOK	273
#define	FALSETOK	274
#define	IROOT	275
#define	UMINUS	276


extern YYSTYPE yylval;
