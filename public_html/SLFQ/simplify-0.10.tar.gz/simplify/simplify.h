#include "polynom.h"

/***************************************************************
 *** Prototype declarations for other functions from this package.
 ***************************************************************/
class Context
{
public:
  int qesimp_count, qecallslen, var_num, cutoff;
  bool fdflag;       // full dimensional cells flag
  bool pflag;        // Print out original formula
  bool aflag;        // Assumption flag
  bool quiet;        // quiet mode flag
  vector<string> VV; // vector of variable names
  string aname;      // Assumptions file name
  string aform;      // Assumptions formula
  string ofname;     // Output file name
  Context() { qecallslen = qesimp_count = 0; 
              fdflag = pflag = aflag = quiet = false; }
};

fpart* qepcaddsimplify(logop* root, Context &C);
fpart* simplify(fpart* root, Context &C, int infflag=0);
