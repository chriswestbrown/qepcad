#include "poly.tab.h"
#include "polynom.h"
#include <algorithm>
#include <sstream>
#include <stdio.h>
#include <unistd.h>
#include "utils.h"

/***************************************************************
 *** Declarations for flex and bison functions and variables.
 ***************************************************************/
extern const char * stringin;
extern int yyparse();
extern FILE* yyin;
extern int myflush();
extern "C" { int yywrap() {return 1; } };


/***************************************************************
 *** Function definitions
 ***************************************************************/
fpart* parsefile(const char * const fn)
{
  // Open file
  FILE* input = fopen(fn,"r"); 
  if (input == NULL) {
    cerr << "File " << fn << " not found!" << endl;
    exit(1); }

  // Parse file
  stringin = 0;
  yyin = input;
  fpart* p = (fpart*)yyparse();
  myflush();
  fclose(input);
  if (p <= (void*)2)
    p = 0;
  return p;
}

fpart* parsestring(const char * const fn)
{
  yyin = (FILE*)0;
  stringin = fn;
  fpart* p = (fpart*)yyparse();
  stringin = 0;
  if (p <= (void*)2)
    p = 0;
  return p;
}

char*  treetostring(fpart *root)
{
  ostringstream os;
  root->write(os);
  char *p = new char[os.str().length() + 1];
  os.str().copy(p,string::npos);
  p[os.str().length()] = 0;
  return p; // Whoever gets this array must delete it!
}

void printversion(ostream &OUT)
{
  /******* VERSION ********************************************/
  /* $Format: "static char* version = \"$ProjectVersion$\";"$ */
static char* version = "0.10";
  /* $Format: "static char* versdate = \"$ProjectDate$\";"$ */
static char* versdate = "Mon, 10 Mar 2003 16:21:26 -0500";

  OUT << "slfq version " << version << ' ' << versdate << endl;
}
