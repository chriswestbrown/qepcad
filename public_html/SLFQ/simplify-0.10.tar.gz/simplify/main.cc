/***************************************************************
 ** SLFQ: Simplifying Large Formulas with QEPCAD
 **
 ** This is the main file for SLFQ.  It uses poly.l & poly.y to
 ** parse formulas, polynom.h to provide a parse-tree data
 ** structure, and search.cc to excise the solution formula from
 ** a QEPCAD output file.
 ***************************************************************/
#include "polynom.h"
#include <algorithm>
#include <sstream>
#include <stdio.h>
#include <unistd.h>
#include "utils.h"
#include "simplify.h"

/***************************************************************
 *** Main 
 ***************************************************************/
int main(int argc, char **argv)
{
  //-- Check argument number. --------------------------//
  if (argc < 2) {
    cerr << "require file to process as 1st argument!" << endl;
    exit(1); }

  //-- Open file & check existence. --------------------//
  if (argc == 2 && strcmp(argv[1],"-v") == 0)
  {
    printversion(cout);
    exit(0);
  }
  FILE* input = fopen(argv[1],"r"); 
  if (input == NULL) {
    cerr << "File not found!" << endl;
    exit(1); }
  fclose(input);

  //-- Check further arguments -------------------------//
  Context C;
  string ofname;
  for(int i = 2; i < argc; i++)
  {
    if (strcmp(argv[i],"-F") == 0)
      C.fdflag = true;
    else if (strcmp(argv[i],"-S") == 0)
    {      
      C.pflag = true;
      if (i + 1 >= argc) { cerr << "No file given for -S option!" << endl; exit(1); }
      ofname = argv[i+1];
      i++;
    }
    else if (strcmp(argv[i],"-A") == 0)
    {
      C.aflag = true;
      if (i + 1 >= argc) { cerr << "No file given for -A option!" << endl; exit(1); }
      C.aname = argv[i+1];
      i++;
      ifstream test(C.aname.c_str());
      if (!test) { cerr << "Assumptions file \"" << C.aname << "\" not found!" << endl; exit(1); }
    }
    else if (strcmp(argv[i],"-a") == 0)
    {
      if (i + 1 >= argc) { cerr << "No formula given for -a option!" << endl; exit(1); }
      i++;
      fpart* ap = parsestring(argv[i]);
      if (ap != 0)
      {
	char *p = treetostring(ap);
	C.aform = p;
	delete ap;
      }
      else
      {
	cerr << "Assumption could not be parsed!" << endl;
	exit(1);
      }
    }
    else if(strcmp(argv[i],"-o") == 0)
    {
      if (i + 1 >= argc) { cerr << "No file name given -o option!" << endl; exit(1); }
      i++;
      C.ofname = argv[i];
    }
    else if(strcmp(argv[i],"-v") == 0)
    {
      printversion(cout);
      cout << endl;
    }
    else if(strcmp(argv[i],"-q") == 0)
    {
      C.quiet = true;
    }
    else
    {
      cerr << "Option \"" << argv[i] << "\" not understood!" << endl;
    }
  }

  //-- Read and parse input.
  fpart* p = parsefile(argv[1]);
  if (p == 0)
  {
    cerr << "Input formula could not be parsed!" << endl;
    exit(1);
  }

  //-- Print out info about what's been read.
  cout << "The input formula is: ";
  p->report(cout);
  cout << endl;
  cout << "It contains " << p->atomnum() << " atomic formulas, "
       << "nested to a depth of " << p->depth() << "." << endl;

  //-- Print out original formula in QEPCAD syntax if requested --//
  if (C.pflag)
  {
    ofstream ofs(ofname.c_str());
    p->write(ofs);
  }

  //-- Read in vector of variables to get ordering.
  cout << "How many variables? ";
  cin >> C.var_num;
  for(int i = 1; i <= C.var_num; i++) {
    string s;
    cout << "Enter variable #" << i << " : ";
    cin >> s;
    C.VV.push_back(s); }

  //-- Cutoff parameter!
  cout << "What should the cutoff number of atomic formulas be? ";
  cin >> C.cutoff;

  //-- Do the simplification!
  fpart *q = simplify(p,C,1);

  //-- Write the output.
  if (C.ofname != "") {
    ofstream out(C.ofname.c_str());
    q->write(out); out << endl;
    if (!C.quiet)
      cout << endl;
    cout << "An equivalent formula has been written to \"" << C.ofname << "\".";
 }
  else {
    if (!C.quiet)
      cout << endl;
    cout << "An equivalent formula is: " << endl;;
    q->write(cout); }
  cout << endl;
  cout << "There were " << C.qesimp_count << " qepcadd runs!" << endl;

  return 0;
}
