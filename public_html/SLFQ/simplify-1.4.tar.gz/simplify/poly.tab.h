#ifndef BISON_POLY_TAB_H
# define BISON_POLY_TAB_H

# ifndef YYSTYPE
#  define YYSTYPE int
#  define YYSTYPE_IS_TRIVIAL 1
# endif
# define	VAR	257
# define	PLUS	258
# define	MINUS	259
# define	PROD	260
# define	EXP	261
# define	NUMBER	262
# define	RELOPTOK	263
# define	ZERO	264
# define	ANDTOK	265
# define	ORTOK	266
# define	LEFTP	267
# define	RIGHTP	268
# define	RSYMBP	269
# define	RSYMBN	270
# define	TRUETOK	271
# define	FALSETOK	272
# define	IROOT	273
# define	UMINUS	274


extern YYSTYPE yylval;

#endif /* not BISON_POLY_TAB_H */
