#ifndef _SLFQ_SIGNAL_
#define _SLFQ_SIGNAL_

void init_SIGINT_handler();

#endif

