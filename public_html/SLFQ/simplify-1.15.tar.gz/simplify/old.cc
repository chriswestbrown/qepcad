/***************************************************************
 *** root :  the root of the formula tree
 *** This function returns an equivalent formula to root, and
 *** one that is hopefully simpler.  The returned value and root
 *** totally distinct data structures, so modifying or deleting
 *** one has no effect on the other.  Note:  this function may
 *** exit to the program with an error if it can't get an
 *** equivalent from QEPCAD.
 ***************************************************************/
fpart* qepcaddsimplify(logop* root, Context &C)
{
  /***** Log number of calls to qepcaddsimplify ***/
  C.qesimp_count++;

  /****** Get formula level! ***/
  int level;
  for(level = C.var_num; !root->does_var_appear(C.VV[level-1]); level--)
    if (level == 0) {
      cerr << "This expression has no variables!!!" << endl;
      exit(1); }

  /***************************************************************
   *** Set up the qepcad input file:
   ***************************************************************/
  char F[40] = "/tmp/qesimpXXXXXX";
  int fp = mkstemp(F);
  if (fp == -1) { cerr << "Unable to open necessary tempfile!" << endl; exit(1); }
  close(fp);
  string f0 = F;
  string f1 = f0+".1", f2 = f0+".2";
  ofstream tmpout(f0.c_str());

  //-- "informative comments" //
  tmpout << "[]" << endl;

  //-- Variable list ---------//
  tmpout << "(" << C.VV[0];
  for(int k = 1; k < level; k++)
    tmpout << "," << C.VV[k];
  tmpout << ")" << endl;

  //-- Level -----------------//
  tmpout << level << endl;

  //-- Formula ---------------//
  tmpout << "[ " << endl;  
  root->write(tmpout);
  tmpout << endl << "]." << endl;

  //-- qepcad commands -------//
  if (C.aflag) {
    tmpout << "assume" << endl;
    ifstream ain(C.aname.c_str());
    for(char c; (c = ain.get()) && !ain.eof(); tmpout << c);
    tmpout << endl;
  }
  if (C.aform != "") {
    tmpout << "assume [" << C.aform << "]" << endl;
  }
  if (C.fdflag)
    tmpout << "measure" << endl << "go" << endl << "go"
	   << endl << "go" << endl << "sol F" << endl 
	   << "quit" << endl;
  else
    tmpout << "go" << endl << "go" << endl 
	   << "go" << endl << "sol E" << endl 
	   << "quit" << endl;    

  /***************************************************************
   *** Call qepcad:  first with 5MB then 50MB garbage collected space.
   *** The call stores just the formula part of the QEPCAD output in
   *** a file.  The tail/head calls that perform this rely QEPCAD B
   *** to print its results in a very particular way (needs QEPCAD
   *** B version 1.9 or higher).  This is brittle, but easy!
   ***************************************************************/
  string QE = "${qe}/bin/qepcad +N";
  system((QE + "5000000 < " + f0 + " | tail -7 | head -3 > " + f1).c_str());
  fpart *sf = parsefile(f1.c_str());
  if (sf == 0)
  {
    C.qesimp_count++;
    cerr << "Upping the garbage collected space size!" << endl;
    system((QE + "50000000 < " + f0 + " | tail -7 | head -3 > " + f1).c_str());
    sf = parsefile(f1.c_str());    
    if (sf == 0)
    {
      system((string("rm -f ") + f0 + ' ' + f1).c_str());
      cerr << "Insufficient memory allocated!" << endl
	   << "Failed on input:" << endl << endl;
      root->write(cerr);
      cerr << endl << endl << "Exiting program!" << endl;
      exit(1);
    }
  }

  /***************************************************************
   *** Construct formula tree for simplified formula and return it.
   ***************************************************************/  
  system((string("rm -f ") + f0 + ' ' + f1).c_str());
  if (sf == 0)
  { 
    system((string("cat ") + f1).c_str());
    cerr << "QEPCAD B output could not be parsed!" << endl;
    exit(1);
  }
  sf->simpleflag = 1;
  return sf;
}
