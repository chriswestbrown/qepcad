/***************************************************************
 ** This file defines the parse-tree data structure used by SLFQ.
 ** The base type for the tree is "fpart", and it just goes on
 ** from there!
 ***************************************************************/
#include <stdlib.h>
#include <fstream>
#include <strings.h>
#include <string>
#include <vector>

using namespace std;

/* Strict Relational Operators */
#define LTOP   1
#define EQOP   2
#define GTOP   4

/* Other Relational Operators */
#define GEOP   6
#define NEOP   5
#define LEOP   3

/*******************************************************************
 *** BASE CLASS fpart formula part
 *******************************************************************/
class fpart
{
public:
  string str;
  int simpleflag; // 0: formula piece never simplified, -1: ?
  virtual void write(ostream &out) = 0;
  virtual int isand() { return 0; }
  virtual int isor()  { return 0; }
  virtual int atomnum() { return -1; }
  virtual int does_var_appear(const string &s) = 0;
  virtual int is_T_F() { return 0; }
  virtual void report(ostream &out) { out << "Not a formula!"; }
  virtual void write_str(ostream &out) { if (str == "") write(out); else out << str; }
  virtual ~fpart() { }
};

/*******************************************************************
 *** BASE CLASS fpart formula part
 *******************************************************************/
class logconst : public fpart
{
  bool val;
 public:
  logconst(bool a) { val = a; simpleflag = 1; }
  int is_T_F() { return 1; }
  bool value() { return val; }
  void write(ostream &out) { if (val) out << "TRUE"; else out << "FALSE"; }
  int atomnum() { return 0; }
  int does_var_appear(const string &s) { return 0; }
  void report(ostream &out) { write(cout); }
};

/*******************************************************************
 *** BASE CLASS ppart : polynomial part
 *******************************************************************/
class ppart : public fpart
{
public:
  virtual int isvar() { return  0; }
  virtual int isbinop() { return  0; }
  virtual ppart* sendneg() = 0;
};

class negop : public ppart
{
public:
  ppart* operand;
  negop(ppart* p) : operand(p) { }
  void write(ostream &out) { out << "-"; operand->write(out); }
  ppart* sendneg() { ppart* p = operand; operand = 0; delete this; return p; }
  int does_var_appear(const string &s) { return operand->does_var_appear(s); }
  virtual ~negop() { if (operand) delete operand; }
};

/*******************************************************************
 *** var
 *******************************************************************/
class var : public ppart
{
public:
  string name;
  var(char* s) : name(s) { }
  void write(ostream &out) { out << name; }
  int isvar() { return  1; }
  ppart* sendneg() { return new negop(this); }
  int does_var_appear(const string &s) { return (s == name); }
};

/*******************************************************************
 *** number
 *******************************************************************/
class number : public ppart
{
public:
  int sign;
  string value;
  number(char* S): value(S), sign(1) { }
  void write(ostream &out) { if (sign == -1) out << '-'; out << value; }
  ppart* sendneg() { sign = -sign; return this; }
  int does_var_appear(const string &s) { return 0; }
};


/*******************************************************************
 *** binop
 *******************************************************************/
class binop : public ppart
{
public:
  ppart *left, *right;
  binop(ppart *p1 = NULL, ppart *p2 = NULL) : left(p1), right(p2) { }
  void write(ostream &out) { left->write(out); opwrite(out); right -> write(out);}
  int isbinop() { return  1; }
  virtual void opwrite(ostream &out) { out << " ? "; }
  int does_var_appear(const string &s) 
  { return left->does_var_appear(s) || right->does_var_appear(s); }
  virtual ~binop() { if (left) delete left; if (right) delete right; }
};

class minusop : public binop
{
public:
  void opwrite(ostream &out) { out << " - "; }
  minusop(ppart *p1 = NULL, ppart *p2 = NULL) : binop(p1,p2) { }
  virtual ppart* sendneg() { swap(left,right); return this; }
};

class addop : public binop
{
public:
  void opwrite(ostream &out) { out << " + "; }
  addop(ppart *p1 = NULL, ppart *p2 = NULL) : binop(p1,p2) { }
  virtual ppart* sendneg() 
  { 
    binop *p; 
    p = new minusop(left->sendneg(),right); 
    left = right = 0; 
    delete this; 
    return p; 
  }
};

class prodop : public binop
{
public:
  void opwrite(ostream &out) { out << " "; }
  prodop(ppart *p1 = NULL, ppart *p2 = NULL) : binop(p1,p2) { }
  virtual ppart* sendneg() { left = left->sendneg(); return this; }
};

class expop : public binop
{
public:
  void opwrite(ostream &out) { out << "^"; }
  expop(ppart *p1 = NULL, ppart *p2 = NULL) : binop(p1,p2) { }
  virtual ppart* sendneg() { return new negop(this); }
};


/*******************************************************************
 *** relop a relational operator -- no longer a "polynomial part"
 *** consists of a polynomial part and a relational operator code
 *******************************************************************/
class relop : public fpart
{
public:
  ppart *pol;
  int relopcode;
  relop(char* theop, ppart *p1 = NULL) : pol(p1) 
  { 
    simpleflag = -1;
    if (!strcmp(theop,"="))
      relopcode = EQOP;
    else if (!strcmp(theop,"<"))
      relopcode = LTOP;
    else if (!strcmp(theop,">"))
      relopcode = GTOP;
    else if (!strcmp(theop,"<="))
      relopcode = LEOP;
    else if (!strcmp(theop,">="))
      relopcode = GEOP;
    else if (!strcmp(theop,"<>"))
      relopcode = NEOP;
    else if (!strcmp(theop,"/="))
      relopcode = NEOP;
    else 
      relopcode = 0;
  }
  void write(ostream &out) { pol->write(out); relwrite(out); out << 0; }
  void relwrite(ostream &out)
  {  
    if (relopcode == 0) out << " ? ";
    else if (relopcode == LTOP) out << " < ";
    else if (relopcode == EQOP) out << " = ";
    else if (relopcode == LEOP) out << " <= ";
    else if (relopcode == GTOP) out << " > ";
    else if (relopcode == NEOP) out << " /= ";
    else if (relopcode == GEOP) out << " >= ";
  }

  void set(ppart *p1) { pol = p1; }

  int atomnum() { return 1; }
  int does_var_appear(const string &s) { return pol->does_var_appear(s); }
  virtual ~relop() { if (pol) delete pol; }
};



/*******************************************************************
 *** irootexp consists of a variable, a relational operator, an 
 *** index and a polynomial.
 *******************************************************************/
class irootexp : public fpart
{
public:
  ppart *pol, *LHS;
  int relopcode;
  number *index;
  irootexp(number* i, ppart *p1 = NULL) : pol(p1), index(i)
  { 
    simpleflag = -1;
  }
  irootexp* set(ppart *p, int op) { LHS = p; relopcode = op; }
  void write(ostream &out) 
  { 
    LHS->write(out); out << ' '; 
    relwrite(out); 
    out << ' ' << "_root_";
    index->write(out);
    out << " "; 
    pol->write(out);
  }
  void relwrite(ostream &out)
  {  
    if (relopcode == 0) out << " ? ";
    else if (relopcode == LTOP) out << " < ";
    else if (relopcode == EQOP) out << " = ";
    else if (relopcode == LEOP) out << " <= ";
    else if (relopcode == GTOP) out << " > ";
    else if (relopcode == NEOP) out << " /= ";
    else if (relopcode == GEOP) out << " >= ";
  }

  int atomnum() { return 1; }
  int does_var_appear(const string &s) { return pol->does_var_appear(s) || LHS->does_var_appear(s); }
  virtual ~irootexp() { if (pol) delete pol; if (LHS) delete LHS; if (index) delete index; }
};

/*******************************************************************
 *** logop : logical operator
 *** This is a base class for logical operators.
     A : vector<fpart*> The operands
 *******************************************************************/
class logop : public fpart
{
public:
  vector<fpart*> A;
  logop(fpart *p1, fpart *p2) : A(2)
  {
    A[0] = p1;
    A[1] = p2;
    simpleflag = 0;
  }
  virtual ~logop() { for(int i = 0; i < A.size(); i++) if (A[i]) delete A[i]; }
  int atomnum()
  {
    int sum = 0;
    for(int i = 0; i < A.size(); i++)
      sum += A[i]->atomnum();
    return sum;
  }
  int does_var_appear(const string &s) 
  {
    for(int i = A.size() - 1; i >= 0; i--)
      if (A[i]->does_var_appear(s))
	return 1;
    return 0;
  }
	    
};



/*******************************************************************
 *** andop
 *******************************************************************/
class andop : public logop
{
public:
  andop(fpart *p1, fpart *p2) : logop(p1,p2) { }
  int isand() { return 1; }

  static fpart* makeand(fpart *p1, fpart *p2)
  {
    if (p1->isand() && p2->isand()) {
      andop *q1 = (andop*)p1;
      andop *q2 = (andop*)p2;
      for(int i = 0; i < q2->A.size(); i++) {
	q1->A.push_back(q2->A[i]);
	q2->A[i] = NULL;
      }
      delete p2;
      return p1; }
    if (p1->isand()) {
      andop *q1 = (andop*)p1;      
      q1->A.push_back(p2);
      return p1; }
    if (p2->isand()) {
      cerr << "order swap!" << endl;
      andop *q2 = (andop*)p2;
      q2->A.push_back(p1);
      return p2; }
    return new andop(p1,p2); 
  }

  void write(ostream &out)
  {
    out << "[ ";
    A[0]->write(out);
    for(int i = 1; i < A.size(); i++) {
      out << " /\\ ";
      A[i]->write(out); }
    out << " ]";
  }   
  
  void write_str(ostream &out)
  {
    if (str == "") {
      out << "[ ";
      A[0]->write_str(out);
      for(int i = 1; i < A.size(); i++) {
	out << " /\\ ";
	A[i]->write_str(out); }
      out << " ]"; }
    else
      out << str;
  }   
  void report(ostream &out) 
  { out << "The AND of " << A.size() << " things!"; }

};

/*******************************************************************
 *** orop
 *******************************************************************/
class orop : public logop
{
public:
  orop(fpart *p1 = NULL, fpart *p2 = NULL) : logop(p1,p2) { }
  int isor() { return 1; }
  static fpart* makeor(fpart *p1, fpart *p2)
  {
    if (p1->isor() && p2->isor()) {
      orop *q1 = (orop*)p1;
      orop *q2 = (orop*)p2;
      for(int i = 0; i < q2->A.size(); i++) {
	q1->A.push_back(q2->A[i]);
	q2->A[i] = NULL;
      }
      delete p2;
      return p1; }
    if (p1->isor()) {
      orop *q1 = (orop*)p1;      
      q1->A.push_back(p2);
      return p1; }
    if (p2->isor()) {
      cerr << "order swap!" << endl;
      orop *q2 = (orop*)p2;
      q2->A.push_back(p1);
      return p2; }
    return new orop(p1,p2); 
  }
  void write(ostream &out)
  {
    out << "[ ";
    A[0]->write(out);
    for(int i = 1; i < A.size(); i++) {
      out << " \\/ ";
      A[i]->write(out); }
    out << " ]";
  }   
  void write_str(ostream &out)
  {
    if (str == "") {
      out << "[ ";
      A[0]->write_str(out);
      for(int i = 1; i < A.size(); i++) {
	out << " \\/ ";
	A[i]->write_str(out); }
      out << " ]"; }
    else
      out << str;
  }   

  void report(ostream &out) 
  { out << "The OR of " << A.size() << " things!"; }
};
