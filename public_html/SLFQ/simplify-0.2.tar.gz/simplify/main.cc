/***************************************************************
 ** SLFQ: Simplifying Large Formulas with QEPCAD
 **
 ** This is the main file for SLFQ.  It uses poly.l & poly.y to
 ** parse formulas, polynom.h to provide a parse-tree data
 ** structure, and search.cc to excise the solution formula from
 ** a QEPCAD output file.
 ***************************************************************/
#include "poly.tab.h"
#include "polynom.h"
#include <stdio.h>
#include <unistd.h>

/***************************************************************
 *** Declarations for flex and bison functions and variables.
 ***************************************************************/
extern int yyparse();
extern FILE* yyin;
extern int myflush();
extern "C" {
int yywrap() {return 1; }
};

/***************************************************************
 *** Prototype declarations for other functions from this package.
 ***************************************************************/
fpart* simplify(fpart* root, int infflag=0);
int special_search(istream &IN);
void special_excise(istream &IN, ostream &OUT);

/***************************************************************
 *** Ssshhhh! Global variables.
 ***************************************************************/
int qesimp_count = 0;
int qecallslen = 0;
int var_num = 0;
vector<string> VV;
int cutoff = 10;
bool fdflag = false; // full dimensional cells flag
bool pflag = false;  // Print out original formula
bool aflag = false;  // Assumption flag
string aname;        // Assumptions file name
/***************************************************************
 *** Main Function
 ***************************************************************/
int main(int argc, char **argv)
{
  //-- Check argument number. --------------------------//
  if (argc < 2) {
    cerr << "require file to process as 1st argument!" << endl;
    exit(1); }

  //-- Open file & check existence. --------------------//
  FILE* input = fopen(argv[1],"r"); 
  if (input == NULL) {
    cerr << "File not found!" << endl;
    exit(1); }

  //-- Check further arguments -------------------------//
  string ofname;
  for(int i = 2; i < argc; i++)
  {
    if (strcmp(argv[i],"-F") == 0)
      fdflag = true;
    else if (strcmp(argv[i],"-S") == 0)
    {      
      pflag = true;
      if (i + 1 >= argc) { cerr << "No file given for -S option!" << endl; exit(1); }
      ofname = argv[i+1];
      i++;
    }
    else if (strcmp(argv[i],"-A") == 0)
    {
      aflag = true;
      if (i + 1 >= argc) { cerr << "No file given for -A option!" << endl; exit(1); }
      aname = argv[i+1];
      i++;
      ifstream test(aname.c_str());
      if (!test) { cerr << "Assumptions file \"" << aname << "\" not found!" << endl; exit(1); }
    }
    else
    {
      cerr << "Option \"" << argv[i] << "\" not understood!" << endl;
      exit(1);
    }
  }

  //-- Read and parse input.
  yyin = input;
  fpart* p;
  p = (fpart*)yyparse();
  myflush();
  fclose(input);

  //-- Print out info about what's been read.
  cout << "Here's what you've got: ";
  p->report(cout);
  cout << endl;
  cout << "There are " << p->atomnum() << " atomic formulas." << endl;

  //-- Print out original formula in QEPCAD syntax if requested --//
  if (pflag)
  {
    ofstream ofs(ofname.begin());
    p->write(ofs);
  }

  //-- Read in vector of variables to get ordering.
  cout << "How many variables? ";
  cin >> var_num;
  for(int i = 1; i <= var_num; i++) {
    string s;
    cout << "Enter variable #" << i << " : ";
    cin >> s;
    VV.push_back(s); }

  //-- Cutoff parameter!
  cout << "What should the cutoff number of atomic formulas be? ";
  cin >> cutoff;

  //-- Do the simplification!
  p = simplify(p,1);

  //-- Write the output.
  char S[30];
  cout << "Enter output file name: (X for stdout) ";
  cin >> S;
  cerr << S << endl;
  if (S[0] != 'X') {
    ofstream out(S);
    p->write(out); out << endl;}
  else {
    p->write(cout); }
  cout << endl;
  cout << "There were " << qesimp_count << " qepcadd runs!" << endl;

}

/***************************************************************
 *** root :  the root of the formula tree
 ***************************************************************/
fpart* qepcaddsimplify(logop* root)
{
  /***** Log number of calls to qepcaddsimplify ***/
  qesimp_count++;

  /****** Get formula level! ***/
  int level;
  for(level = var_num; !root->does_var_appear(VV[level-1]); level--)
    if (level == 0) {
      cerr << "This expression has no variables!!!" << endl;
      exit(1); }

  /***************************************************************
   *** Set up the qepcad input file:
   ***************************************************************/
  char F[40] = "/tmp/qesimpXXXXXX";
  int fp = mkstemp(F);
  if (fp == -1) { cerr << "Unable to open necessary tempfile!" << endl; exit(1); }
  close(fp);
  string f0 = F;
  string f1 = f0+".1", f2 = f0+".2";
  ofstream tmpout(f0.c_str());

  //-- "informative comments" //
  tmpout << "[]" << endl;

  //-- Variable list ---------//
  tmpout << "(" << VV[0];
  for(int k = 1; k < level; k++)
    tmpout << "," << VV[k];
  tmpout << ")" << endl;

  //-- Level -----------------//
  tmpout << level << endl;

  //-- Formula ---------------//
  tmpout << "[ " << endl;  
  root->write(tmpout);
  tmpout << endl << "]." << endl;

  //-- qepcad commands -------//
  if (aflag) {
    tmpout << "assume" << endl;
    ifstream ain(aname.c_str());
    for(char c; (c = ain.get()) && !ain.eof(); tmpout << c);
    tmpout << endl;
  }
  if (fdflag)
    tmpout << "measure" << endl << "go" << endl << "go"
	   << endl << "go" << endl << "sol F" << endl 
	   << "quit" << endl;
  else
    tmpout << "go" << endl << "go" << endl 
	   << "go" << endl << "sol E" << endl 
	   << "quit" << endl;    

  /***************************************************************
   *** Call qepcad:  first with 5MB then 50MB garbage collected space.
   *** result will be stored in qesimp1.  If a constant value results
   *** just return it.
   ***************************************************************/
  string QE = "${qe}/bin/qepcad +N";
  string command = QE + "5000000 < " + f0 + " > " + f1;
  system(command.c_str());

  {
    ifstream IN(f1.c_str());
    int t = special_search(IN);
    IN.close();

    if (t == 1)  return new logconst(true);
    if (t == 2)  return new logconst(false);
    if (t == 3) {
      qesimp_count++;
      cerr << "Upping the garbage collected space size!" << endl;
      string command = QE + "50000000 < " + f0 + " > " + f1;
      system(command.c_str());

      ifstream IN("f1.c_str()");
      int t = special_search(IN);
      IN.close();
      if (t == 1)  return new logconst(true);
      if (t == 2)  return new logconst(false);	
      if (t == 3) {
	cerr << "Insufficient memory allocated!" << endl
	     << "Failed on input:" << endl << endl;
	root->write(cerr);
	cerr << endl << endl << "Exiting program!" << endl;
	exit(1); } }
  }

  /***************************************************************
   *** Remove new formula from output and store in qesimp2
   ***************************************************************/  
  {
    ifstream IN(f1.c_str());
    ofstream OUT(f2.c_str());
    special_excise(IN,OUT);
  }

  /***************************************************************
   *** Construct formula tree for simplified formula and return it.
   ***************************************************************/  
  FILE* input = fopen(f2.c_str(),"r");
  yyin = input;
  fpart* sf = (fpart*)yyparse();
  myflush();
  fclose(input);
  sf->simpleflag = 1;
  string rm = "rm -f ";
  system((rm + f0 + ' ' + f1 + ' ' + f2).c_str());
  return sf;
}

/***************************************************************
 ***
 root :  a pointer to the root node of a formula expression tree.
 ***
 ***************************************************************/
fpart* simplify(fpart* root, int infflag)
{

  /* It's an atom or a constant or already simplified, simply return. */
  if (root->simpleflag > 0)
    return root;

  logop *Root = (logop*)root; //-- Root is the logical operator at the root of the tree.
  
  /***************************************************************
   *** Call QEPCAD directly
   ***************************************************************/  
  if (Root->simpleflag == - 1 || Root->atomnum() < cutoff)
    return qepcaddsimplify(Root);

  /***************************************************************
   *** Simplify pieces
   ***************************************************************/  
  int N = Root->A.size();     //-- N is the number of operands of root.
  for(int i = 0; i < N; i++) {

    //-- inflag --//
    if (infflag)
      if (Root->isand())
	cout << "Simplifying conjunct number " << i + 1 << endl;
      else if (Root->isor())
	cout << "Simplifying disjunct number " << i + 1 << endl;
    
    // Simplify Root->A[i]
    fpart* p;
    if (Root->A[i]->simpleflag == 0)
      p = simplify(Root->A[i]);
    else if (Root->A[i]->simpleflag == -1)
      p = qepcaddsimplify((logop*)(Root->A[i]));
    else
      continue;

    //-- inflag --//
    if (infflag) {
      cout << "Subformula " << i + 1 << ":" << endl;
      p->write(cout);
      cout << endl; }
    else {
      for(int i = 0; i < qecallslen; i++) cerr << char(8);
      cerr << qesimp_count;
      int k = 1, j = 1;
      while(qesimp_count > j) { k++; j *= 10; }
      if (qesimp_count % 10 == 0)
	qecallslen = k;
      else
	qecallslen = k - 1;
    }
    
    //-- quick decision when subformula's a constant. --//
    if (p->is_T_F()) {
      if (Root->isand() && ((logconst*)p)->value() == false) {
	delete root;
	return p; }
      if (Root->isor() &&  ((logconst*)p)->value() == true) {
	delete root;
	return p; } }
    
    //-- replace old subformula with new. --//
    if (p != Root->A[i]) {
      delete Root->A[i];
      Root->A[i] = p; } }
  
  
  /***************************************************************
   *** Get rid of holes
   ***************************************************************/
  vector<fpart*> Temp;
  for(int i = 0; i < N; i++)
    if (!Root->A[i]->is_T_F())
    {
      Temp.push_back(Root->A[i]);
      Root->A[i] = 0;
    }
    else
    {
      delete Root->A[i];
      Root->A[i] = 0;
    }
  Root->A.clear();

  N = Temp.size();

  if (N == 0) {
    if (Root->isand()) {
      delete root;
      return new logconst(true); }
    if (Root->isor()) {
      delete root;
      return new logconst(false); } }

  if (N == 1) {
    fpart* p = Temp[0];
    delete Root;
    return p; }

  if (N == 2) {
    Root->A.push_back(Temp[0]);
    Root->A.push_back(Temp[1]);
    return qepcaddsimplify(Root); }
    
  for(int j = 0; j < N/2; j++) {
    if (Root->isand())
      Root->A.push_back(new andop(Temp[2*j],Temp[2*j + 1]));
    else
      Root->A.push_back(new orop(Temp[2*j],Temp[2*j + 1])); 
    Root->A.back()->simpleflag = -1; }
  if (N % 2)
    Root->A.push_back(Temp[N-1]);
  root = Root;


  return simplify(root);
}
