#include <fstream.h>
#include <string.h>
/*

  returns 1 if the phrase "Input is identically F" appears in input.
  returns 2 if the phrase "Input is identically T" appears in input.
  returns 3 if "FAIL" appears in the last line of input.
 */

int special_search(istream &IN)
{
  char line[5000];
  
  while(IN.getline(line,5000)) {
    if (strcmp(line,"TRUE") == 0)
      return 1;

    if (strcmp(line,"FALSE") == 0)
      return 2;

    if (strncmp(line,"Now the FAIL",12) == 0)
      return 3; }

}

/*

 */

void special_excise(istream &IN, ostream &OUT)
{
  char line[5000];
  int flag = 0;
  
  while(IN.getline(line,5000)) {
    if (strcmp(line,"An equivalent quantifier-free formula:") == 0) {
      flag = 1;
      OUT << "[" << endl; }
    else if (flag && strcmp(line,"Before Solution >") == 0) {
      OUT << "\n];" << endl;
      return; }
    else if (flag)
      OUT << line;
  }
}
