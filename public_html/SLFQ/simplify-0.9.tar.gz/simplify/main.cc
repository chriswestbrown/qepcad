/***************************************************************
 ** SLFQ: Simplifying Large Formulas with QEPCAD
 **
 ** This is the main file for SLFQ.  It uses poly.l & poly.y to
 ** parse formulas, polynom.h to provide a parse-tree data
 ** structure, and search.cc to excise the solution formula from
 ** a QEPCAD output file.
 ***************************************************************/
#include "poly.tab.h"
#include "polynom.h"
#include <algorithm>
#include <sstream>
#include <stdio.h>
#include <unistd.h>

/***************************************************************
 *** Declarations for flex and bison functions and variables.
 ***************************************************************/

extern const char * stringin;
extern int yyparse();
extern FILE* yyin;
extern int myflush();
extern "C" {
int yywrap() {return 1; }
};

/***************************************************************
 *** Prototype declarations for other functions from this package.
 ***************************************************************/
class Context
{
public:
  int qesimp_count, qecallslen, var_num, cutoff;
  bool fdflag;       // full dimensional cells flag
  bool pflag;        // Print out original formula
  bool aflag;        // Assumption flag
  vector<string> VV; // vector of variable names
  string aname;      // Assumptions file name
  string aform;      // Assumptions formula
  Context() { qecallslen = qesimp_count = 0; 
              fdflag = pflag = aflag = false; }
};

int special_search(istream &IN);
void special_excise(istream &IN, ostream &OUT);
fpart* qepcaddsimplify(logop* root, Context &C);
fpart* simplify(fpart* root, Context &C, int infflag=0);
fpart* parsefile(const char * const fn);
fpart* parsestring(const char * const fn);
char*  treetostring(fpart *root);
fpart* stringtotree(const char *p) { return parsestring(p); } // Just for Vespa

/***************************************************************
 *** Main Function
 ***************************************************************/
int main(int argc, char **argv)
{
  //-- Check argument number. --------------------------//
  if (argc < 2) {
    cerr << "require file to process as 1st argument!" << endl;
    exit(1); }

  //-- Open file & check existence. --------------------//
  FILE* input = fopen(argv[1],"r"); 
  if (input == NULL) {
    cerr << "File not found!" << endl;
    exit(1); }
  fclose(input);

  //-- Check further arguments -------------------------//
  Context C;
  string ofname;
  for(int i = 2; i < argc; i++)
  {
    if (strcmp(argv[i],"-F") == 0)
      C.fdflag = true;
    else if (strcmp(argv[i],"-S") == 0)
    {      
      C.pflag = true;
      if (i + 1 >= argc) { cerr << "No file given for -S option!" << endl; exit(1); }
      ofname = argv[i+1];
      i++;
    }
    else if (strcmp(argv[i],"-A") == 0)
    {
      C.aflag = true;
      if (i + 1 >= argc) { cerr << "No file given for -A option!" << endl; exit(1); }
      C.aname = argv[i+1];
      i++;
      ifstream test(C.aname.c_str());
      if (!test) { cerr << "Assumptions file \"" << C.aname << "\" not found!" << endl; exit(1); }
    }
    else if (strcmp(argv[i],"-a") == 0)
    {
      i++;
      yyin = (FILE*)0;
      stringin = argv[i];
      fpart* ap = (fpart*)yyparse();
      stringin = 0;
      char *p = treetostring(ap);
      C.aform = p;
      delete [] p;
    }
    else
    {
      cerr << "Option \"" << argv[i] << "\" not understood!" << endl;
      exit(1);
    }
  }

  //-- Read and parse input.
  fpart* p = parsefile(argv[1]);

  //-- Print out info about what's been read.
  cout << "Here's what you've got: ";
  p->report(cout);
  cout << endl;
  cout << "There are " << p->atomnum() << " atomic formulas." << endl;

  //-- Print out original formula in QEPCAD syntax if requested --//
  if (C.pflag)
  {
    ofstream ofs(ofname.c_str());
    p->write(ofs);
  }

  //-- Read in vector of variables to get ordering.
  cout << "How many variables? ";
  cin >> C.var_num;
  for(int i = 1; i <= C.var_num; i++) {
    string s;
    cout << "Enter variable #" << i << " : ";
    cin >> s;
    C.VV.push_back(s); }

  //-- Cutoff parameter!
  cout << "What should the cutoff number of atomic formulas be? ";
  cin >> C.cutoff;

  //-- Do the simplification!
  fpart *q = simplify(p,C,1);

  //-- Write the output.
  char S[30];
  cout << "Enter output file name: (X for stdout) ";
  cin >> S;
  cerr << S << endl;
  if (S[0] != 'X') {
    ofstream out(S);
    q->write(out); out << endl;}
  else {
    q->write(cout); }
  cout << endl;
  cout << "There were " << C.qesimp_count << " qepcadd runs!" << endl;

}

/***************************************************************
 *** root :  the root of the formula tree
 *** This function returns an equivalent formula to root, and
 *** one that is hopefully simpler.  The returned value and root
 *** totally distinct data structures, so modifying or deleting
 *** one has no effect on the other.  Note:  this function may
 *** exit to the program with an error if it can't get an
 *** equivalent from QEPCAD.
 ***************************************************************/
fpart* qepcaddsimplify(logop* root, Context &C)
{
  /***** Log number of calls to qepcaddsimplify ***/
  C.qesimp_count++;

  /****** Get formula level! ***/
  int level;
  for(level = C.var_num; !root->does_var_appear(C.VV[level-1]); level--)
    if (level == 0) {
      cerr << "This expression has no variables!!!" << endl;
      exit(1); }

  /***************************************************************
   *** Set up the qepcad input file:
   ***************************************************************/
  char F[40] = "/tmp/qesimpXXXXXX";
  int fp = mkstemp(F);
  if (fp == -1) { cerr << "Unable to open necessary tempfile!" << endl; exit(1); }
  close(fp);
  string f0 = F;
  string f1 = f0+".1", f2 = f0+".2";
  ofstream tmpout(f0.c_str());

  //-- "informative comments" //
  tmpout << "[]" << endl;

  //-- Variable list ---------//
  tmpout << "(" << C.VV[0];
  for(int k = 1; k < level; k++)
    tmpout << "," << C.VV[k];
  tmpout << ")" << endl;

  //-- Level -----------------//
  tmpout << level << endl;

  //-- Formula ---------------//
  tmpout << "[ " << endl;  
  root->write(tmpout);
  tmpout << endl << "]." << endl;

  //-- qepcad commands -------//
  if (C.aflag) {
    tmpout << "assume" << endl;
    ifstream ain(C.aname.c_str());
    for(char c; (c = ain.get()) && !ain.eof(); tmpout << c);
    tmpout << endl;
  }
  if (C.aform != "") {
    tmpout << "assume [" << C.aform << "]" << endl;
  }
  if (C.fdflag)
    tmpout << "measure" << endl << "go" << endl << "go"
	   << endl << "go" << endl << "sol F" << endl 
	   << "quit" << endl;
  else
    tmpout << "go" << endl << "go" << endl 
	   << "go" << endl << "sol E" << endl 
	   << "quit" << endl;    

  /***************************************************************
   *** Call qepcad:  first with 5MB then 50MB garbage collected space.
   *** result will be stored in qesimp1.  If a constant value results
   *** just return it.
   ***************************************************************/
  string QE = "${qe}/bin/qepcad +N";
  string command = QE + "5000000 < " + f0 + " > " + f1;
  system(command.c_str());

  {
    ifstream IN(f1.c_str());
    int t = special_search(IN);
    IN.close();
    string rm = "rm -f ";
    rm = rm + f0 + ' ' + f1;
    if (t == 1)  { system(rm.c_str()); return new logconst(true); }
    if (t == 2)  { system(rm.c_str()); return new logconst(false); }	
    if (t == 3) {
      C.qesimp_count++;
      cerr << "Upping the garbage collected space size!" << endl;
      string command = QE + "50000000 < " + f0 + " > " + f1;
      system(command.c_str());

      ifstream IN(f1.c_str());
      int t = special_search(IN);
      IN.close();  
      if (t == 1)  { system(rm.c_str()); return new logconst(true); }
      if (t == 2)  { system(rm.c_str()); return new logconst(false); }	
      if (t == 3) {
	system(rm.c_str());
	cerr << "Insufficient memory allocated!" << endl
	     << "Failed on input:" << endl << endl;
	root->write(cerr);
	cerr << endl << endl << "Exiting program!" << endl;
	exit(1); } }
  }

  /***************************************************************
   *** Remove new formula from output and store in qesimp2
   ***************************************************************/  
  {
    ifstream IN(f1.c_str());
    ofstream OUT(f2.c_str());
    special_excise(IN,OUT);
  }

  /***************************************************************
   *** Construct formula tree for simplified formula and return it.
   ***************************************************************/  
  fpart *sf = parsefile(f2.c_str());
  sf->simpleflag = 1;
  string rm = "rm -f ";
  system((rm + f0 + ' ' + f1 + ' ' + f2).c_str());
  return sf;
}

/***************************************************************
 ***
 root :  a pointer to the root node of a formula expression tree.
 infflag: just a flag to tell you if you're at the top level.
 ***
 *** This program returns an fpart formula that is equivalent 
 *** to root (hopefully simpler!). Note:  the returned data
 *** structure is totally distinct from root, and the formula
 *** structure pointed to by root is unchanged by the operation!
 ***
 ***************************************************************/
fpart* simplify(fpart* root, Context &C, int infflag)
{

  /* It's an atom or a constant or already simplified, simply return. */
  if (root->simpleflag > 0)
    return root->copy();

  logop* &Root = (logop*)root; //-- Root is the logical operator at the root of the tree.
  
  /***************************************************************
   *** Call QEPCAD directly
   ***************************************************************/  
  if (Root->simpleflag == -1 || Root->atomnum() < C.cutoff)
    return qepcaddsimplify(Root,C);

  /***************************************************************
   *** Simplify pieces
   ***************************************************************/
  vector<fpart*> simplifiedPieces;
  int N = Root->A.size();     //-- N is the number of operands of root.
  for(int i = 0; i < N; i++) {

    //-- Prints feedback for user --//
    if (infflag)
      if (Root->isand())
	cout << "Simplifying conjunct number " << i + 1 << endl;
      else if (Root->isor())
	cout << "Simplifying disjunct number " << i + 1 << endl;
    
    // Simplify Root->A[i]
    fpart* p;
    if (Root->A[i]->simpleflag == 0)
      p = simplify(Root->A[i],C);
    else if (Root->A[i]->simpleflag == -1)
      p = qepcaddsimplify((logop*)(Root->A[i]),C);
    else // simpleflag is 1
      p = Root->A[i]->copy();

    //-- This chunk just prints feedback for user! --//
    if (infflag) {
      cout << "Subformula " << i + 1 << ":" << endl;
      p->write(cout);
      cout << endl; }
    else {
      for(int m = 0; m < C.qecallslen; m++) cerr << char(8);
      cerr << C.qesimp_count;
      int k = 1, j = 10;
      while(C.qesimp_count >= j) { k++; j *= 10; }
      if (C.qesimp_count % 10 == 0)
	C.qecallslen = k;
      else
	C.qecallslen = k;
    }
    
    //-- Try quick decision when subformula's a constant. --//
    if (p->is_T_F())
    {
      logconst* q = dynamic_cast<logconst*>(p);
      if (Root->isand() && q->value() == false || Root->isor() &&  q->value() == true)
      {
	for(int j = 0; j < simplifiedPieces.size(); j++)
	  delete simplifiedPieces[j];
	return p;
      }
      else
	delete p;
    }
    else
      //-- replace old subformula with new. --//
      simplifiedPieces.push_back(p);
  }
  
  
  /***************************************************************
   *** Create the conjunction/disjunction of the simplified pieces
   ***************************************************************/
  N = simplifiedPieces.size();

  // Empty conjunction or disjunction
  if (N == 0)
    return Root->isand() ? new logconst(true) : new logconst(false);

  // Conjunction or disjuntion of 1 element
  if (N == 1)
    return simplifiedPieces[0];

  // Conjunction or disjunction of 2 or more elements (simplify results!)
  logop *p = Root->isand() ? (logop*) new andop : (logop*) new orop;
  if (N == 2) {
    p->A.push_back(simplifiedPieces[0]);
    p->A.push_back(simplifiedPieces[1]);
    p->simpleflag = -1;
  }
  else {
    for(int j = 0; j < N/2; j++) 
    {
      if (p->isand())
	p->A.push_back(new andop(simplifiedPieces[2*j],simplifiedPieces[2*j + 1]));
      else
	p->A.push_back(new orop(simplifiedPieces[2*j],simplifiedPieces[2*j + 1])); 
      p->A.back()->simpleflag = -1;
    }
    if (N % 2)
      p->A.push_back(simplifiedPieces[N-1]);
    p->simpleflag = 0;
  }

  fpart *q = simplify(p,C);
  delete p;
  return q;
}

fpart* parsefile(const char * const fn)
{
  // Open file
  FILE* input = fopen(fn,"r"); 
  if (input == NULL) {
    cerr << "File " << fn << " not found!" << endl;
    exit(1); }

  // Parse file
  stringin = 0;
  yyin = input;
  fpart* p = (fpart*)yyparse();
  myflush();
  fclose(input);
  return p;
}

fpart* parsestring(const char * const fn)
{
  yyin = (FILE*)0;
  stringin = fn;
  fpart* p = (fpart*)yyparse();
  stringin = 0;
  return p;
}

char*  treetostring(fpart *root)
{
  ostringstream os;
  root->write(os);
  char *p = new char[os.str().length() + 1];
  os.str().copy(p,string::npos);
  p[os.str().length()] = 0;
  return p; // Whoever gets this array must delete it!
}
