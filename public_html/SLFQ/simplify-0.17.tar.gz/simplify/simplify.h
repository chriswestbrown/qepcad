#ifndef _SLFQ_SIMPLIFY_
#define _SLFQ_SIMPLIFY_
#include "polynom.h"

/***************************************************************
 *** Prototype declarations for other functions from this package.
 ***************************************************************/
class Context
{
public:
  int qesimp_count, qecallslen, var_num, cutoff;
  bool fdflag;       // full dimensional cells flag
  bool pflag;        // Print out original formula
  bool aflag;        // Assumption flag
  bool quiet;        // quiet mode flag
  vector<string> VV; // vector of variable names
  string aname;      // Assumptions file name
  string aform;      // Assumptions formula
  string ofname;     // Output file name
  string sfname;     // "Save-input" file name
  string ifname;     // input file name ("" means stdin)
  string SGCASize ;  // Saclib garbage collected array size 
                     // Number of cells (in millions)
  Context() { qecallslen = qesimp_count = 0; cutoff = 2; 
              fdflag = pflag = aflag = quiet = false; 
              SGCASize = "5"; }
};

void init(Context &C);
void cleanup();
fpart* qepcaddsimplify(logop* root, Context &C);
fpart* simplify(fpart* root, Context &C, int infflag=0);

#endif
