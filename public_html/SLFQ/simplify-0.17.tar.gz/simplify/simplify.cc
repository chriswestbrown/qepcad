#include "polynom.h"
#include <algorithm>
#include <sstream>
#include <stdio.h>
#include <unistd.h>
#include "utils.h"
#include "simplify.h"
#include "qepcad.h"
#include <cstring>

string posIntToStr(int x)
{
  if (x == 0) return "";
  return posIntToStr(x/10) + char(x%10 + '0');
}

void init(Context &C)
{
  int argc = 2,ac;
  char **argv,**av;
  argv = new char*[2];
  string N = "+N" + C.SGCASize + "000000";
  argv[1] = new char[30];
  strcpy(argv[1],N.c_str());
  ARGSACLIB(argc,argv,&ac,&av);
  BEGINSACLIB((Word *)&argc);
  BEGINQEPCAD();
  delete [] argv;
}

Word saclibvarlist(vector<string> &VV)
{
  // Create SACLIB var list
  Word V = NIL;
  for(vector<string>::iterator i = VV.begin(); i != VV.end(); ++i)
    V = COMP(LFS((char*)((*i).c_str())),V);
  V = CINV(V);
  return V;
}

Word string2UnNormForm(const string &S, Word V)
{
  
  // Convert from string to QEPCAD Unnormalized Formula
  string SIN = S + ".\n";
  Word F, t;
  INSTRING = (string*)(&SIN);
  i_INSTRING = 0;
  QFFRDR(V,&F,&t);
  CREAD();
  INSTRING = 0;
  if (t == 0) 
  { 
    cerr << "QEPCADB could not understand the formula:" << endl
	 << SIN << endl;
    exit(1);
  }

  return F;
}

string unNormForm2string(Word F, Word V)
{
  // Convert from Unnormalized QEPCAD formula to string
  string OTS;
  OUTSTRING = &OTS;
  QFFWR(V,F);
  OUTSTRING = 0;
  return OTS;
}


fpart* qepcaddsimplifyMOD(logop* root, Context &C)
{
  // Log number of calls to qepcaddsimplify
  C.qesimp_count++;

  // Create SACLIB var list
  Word V = saclibvarlist(C.VV);

  // Get formula as a string
  ostringstream os;
  root->write(os);

  // Construct QEPCAD Input formula
  Word F = string2UnNormForm(os.str(),V);
  Word Fs = LIST4(C.VV.size(),C.VV.size(),NIL,F);

  // Initialize QEPCAD problem
  QepcadCls Q;
  Q.SETINPUTFORMULA(V,Fs);
  
  // Add assumptions if any
  if (C.aform != "")
  {
    Word A = string2UnNormForm(C.aform,V);
    Q.SETASSUMPTIONS(A);
  }

  // Create CAD & get simplified equivalent formula
  Q.CADautoConst();
  Word Fd = Q.GETDEFININGFORMULA();
  
  // Translate to string
  string OTS = unNormForm2string(Fd,V);
  
  // Translate trivial true/false 
  if (OTS == "0 = 0") OTS = "TRUE";
  if (OTS == "0 /= 0") OTS = "FALSE";

  return parsestring(OTS.c_str());
}

void cleanup()
{
  SWRITE("\n=====================  The End  =======================\n");
  STATSACLIB();
  ENDQEPCAD();
  ENDSACLIB(SAC_FREEMEM);  
}

/***************************************************************
 *** root :  the root of the formula tree
 *** This function returns an equivalent formula to root, and
 *** one that is hopefully simpler.  The returned value and root
 *** totally distinct data structures, so modifying or deleting
 *** one has no effect on the other.  Note:  this function may
 *** exit to the program with an error if it can't get an
 *** equivalent from QEPCAD.
 ***************************************************************/
fpart* qepcaddsimplify(logop* root, Context &C)
{
  /***** Log number of calls to qepcaddsimplify ***/
  C.qesimp_count++;

  /****** Get formula level! ***/
  int level;
  for(level = C.var_num; !root->does_var_appear(C.VV[level-1]); level--)
    if (level == 0) {
      cerr << "This expression has no variables!!!" << endl;
      exit(1); }

  /***************************************************************
   *** Set up the qepcad input file:
   ***************************************************************/
  char F[40] = "/tmp/qesimpXXXXXX";
  int fp = mkstemp(F);
  if (fp == -1) { cerr << "Unable to open necessary tempfile!" << endl; exit(1); }
  close(fp);
  string f0 = F;
  string f1 = f0+".1", f2 = f0+".2";
  ofstream tmpout(f0.c_str());

  //-- "informative comments" //
  tmpout << "[]" << endl;

  //-- Variable list ---------//
  tmpout << "(" << C.VV[0];
  for(int k = 1; k < level; k++)
    tmpout << "," << C.VV[k];
  tmpout << ")" << endl;

  //-- Level -----------------//
  tmpout << level << endl;

  //-- Formula ---------------//
  tmpout << "[ " << endl;  
  root->write(tmpout);
  tmpout << endl << "]." << endl;

  //-- qepcad commands -------//
  if (C.aflag) {
    tmpout << "assume" << endl;
    ifstream ain(C.aname.c_str());
    for(char c; (c = ain.get()) && !ain.eof(); tmpout << c);
    tmpout << endl;
  }
  if (C.aform != "") {
    tmpout << "assume [" << C.aform << "]" << endl;
  }
  if (C.fdflag)
    tmpout << "measure" << endl << "go" << endl << "go"
	   << endl << "go" << endl << "sol F" << endl 
	   << "quit" << endl;
  else
    tmpout << "go" << endl << "go" << endl 
	   << "go" << endl << "sol E" << endl 
	   << "quit" << endl;    

  /***************************************************************
   *** Call qepcad:  first with 5MB then 50MB garbage collected space.
   *** The call stores just the formula part of the QEPCAD output in
   *** a file.  The tail/head calls that perform this rely QEPCAD B
   *** to print its results in a very particular way (needs QEPCAD
   *** B version 1.9 or higher).  This is brittle, but easy!
   ***************************************************************/
  string QE = "${qe}/bin/qepcad +N";
  system((QE + "5000000 < " + f0 + " | tail -7 | head -3 > " + f1).c_str());
  fpart *sf = parsefile(f1.c_str());
  if (sf == 0)
  {
    C.qesimp_count++;
    cerr << "Upping the garbage collected space size!" << endl;
    system((QE + "50000000 < " + f0 + " | tail -7 | head -3 > " + f1).c_str());
    sf = parsefile(f1.c_str());    
    if (sf == 0)
    {
      system((string("rm -f ") + f0 + ' ' + f1).c_str());
      cerr << "Insufficient memory allocated!" << endl
	   << "Failed on input:" << endl << endl;
      root->write(cerr);
      cerr << endl << endl << "Exiting program!" << endl;
      exit(1);
    }
  }

  /***************************************************************
   *** Construct formula tree for simplified formula and return it.
   ***************************************************************/  
  system((string("rm -f ") + f0 + ' ' + f1).c_str());
  if (sf == 0)
  { 
    system((string("cat ") + f1).c_str());
    cerr << "QEPCAD B output could not be parsed!" << endl;
    exit(1);
  }
  sf->simpleflag = 1;
  return sf;
}

/***************************************************************
 ***
 root   : a pointer to the root node of a formula expression tree.
 C      : the "Context" for this simplification. 
 infflag: just a flag to tell you if you're at the top level.
 ***
 *** This program returns an fpart formula that is equivalent 
 *** to root (hopefully simpler!). Note:  the returned data
 *** structure is totally distinct from root, and the formula
 *** structure pointed to by root is unchanged by the operation!
 ***
 ***************************************************************/
fpart* simplify(fpart* root, Context &C, int infflag)
{

  /* It's an atom or a constant or already simplified, simply return. */
  if (root->simpleflag > 0)
    return root->copy();

  logop* &Root = (logop*)root; //-- Root is the logical operator at the root of the tree.
  
  /***************************************************************
   *** Call QEPCAD directly
   ***************************************************************/  
  if (Root->simpleflag == -1 || Root->atomnum() < C.cutoff)
    return qepcaddsimplifyMOD(Root,C);

  /***************************************************************
   *** Simplify pieces
   ***************************************************************/
  vector<fpart*> simplifiedPieces;
  int N = Root->A.size();     //-- N is the number of operands of root.
  for(int i = 0; i < N; i++) {

    //-- Prints feedback for user --//
    if (infflag && !C.quiet)
      if (Root->isand())
	cout << "Simplifying conjunct number " << i + 1 << endl;
      else if (Root->isor())
	cout << "Simplifying disjunct number " << i + 1 << endl;
    
    // Simplify Root->A[i]
    fpart* p;
    if (Root->A[i]->simpleflag == 0)
      p = simplify(Root->A[i],C);
    else if (Root->A[i]->simpleflag == -1)
      p = qepcaddsimplifyMOD((logop*)(Root->A[i]),C);
    else // simpleflag is 1
      p = Root->A[i]->copy();
    p->simpleflag = 1;

    //-- This chunk just prints feedback for user! --//
    if (infflag && !C.quiet) {
      cout << "Subformula " << i + 1 << ":" << endl;
      p->write(cout);
      cout << endl; }
    else if (!C.quiet) {
      for(int m = 0; m < C.qecallslen; m++) cerr << char(8);
      cerr << C.qesimp_count;
      int k = 1, j = 10;
      while(C.qesimp_count >= j) { k++; j *= 10; }
      if (C.qesimp_count % 10 == 0)
	C.qecallslen = k;
      else
	C.qecallslen = k;
    }
    
    //-- Try quick decision when subformula's a constant. --//
    if (p->is_T_F())
    {
      logconst* q = dynamic_cast<logconst*>(p);
      if (Root->isand() && q->value() == false || Root->isor() &&  q->value() == true)
      {
	for(int j = 0; j < simplifiedPieces.size(); j++)
	  delete simplifiedPieces[j];
	return p;
      }
      else
	delete p;
    }
    else
      //-- replace old subformula with new. --//
      simplifiedPieces.push_back(p);
  }
  
  
  /***************************************************************
   *** Create the conjunction/disjunction of the simplified pieces
   ***************************************************************/
  fpart *q = 0;
  N = simplifiedPieces.size();
  int ac = 0; for(int i = 0; i < N; ++i) ac += simplifiedPieces[i]->atomnum();

  // Empty conjunction/disjunction
  if (N == 0) {
    q = Root->isand() ? new logconst(true) : new logconst(false); 
    q->simpleflag = 1; // Mark as already simplified
  }

  // Conjunction/disjuntion of 1 element
  else if (N == 1) {
    q = simplifiedPieces[0]; 
    q->simpleflag = 1; // Mark as already simplified
  }

  // Conjunction/disjunction of 2 elements or total atomcount <= cutoff
  else if (N == 2 || ac <= C.cutoff) {
    logop *p = Root->isand() ? (logop*) new andop : (logop*) new orop;     
    for(int i = 0; i < N; ++i) p->A.push_back(simplifiedPieces[i]);
    p->simpleflag = -1; // Mark as simplify by direct QEPCAD call
    q = simplify(p,C);
    delete p;
  }

  // Conjunction or disjunction of more than 2 elements with more than cutoff atoms
  else {    
    logop *p = Root->isand() ? (logop*) new andop : (logop*) new orop, *r = 0;
    int j = 0, k = 0;
    while (j < N)
    {
      if (k <= 1 || r->atomnum() + simplifiedPieces[j]->atomnum() <= C.cutoff) {
	if (k == 0) { r = Root->isand() ? (logop*) new andop : (logop*) new orop; r->simpleflag = -1; }
	r->A.push_back(simplifiedPieces[j]);
	++k; 
	++j; }
      else {
	p->A.push_back(r);
	r = 0; k = 0; }
    }
    if (k != 0) {
      if (r->A.size() == 1) { p->A.push_back(r->A[0]); r->A[0] = 0; delete r; }
      else { p->A.push_back(r); }
    }
    p->simpleflag = 0; // Mark as simplify pieces
    q = simplify(p,C);
    delete p; 
  }

  return q;
}
