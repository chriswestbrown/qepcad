/*======================================================================
                      t <- VERIFYCONSTSIGN(r,P,s)

Verify constant sign.

Inputs
 P : an r-variate integral saclib poly with deg_{xr}(P) > 0
 s : 1 or 0

Output
 t : true if the procedure is able to verify that the
     polynomial is everywhere positive if s = 1 and
     everywhere non-negative if s = 0.  This is just supposed to
     be a quick test!
======================================================================*/
#include "qepcad.h"

BDigit VERIFYCONSTSIGN(BDigit r, Word P, BDigit s)
{
  BDigit t;
  
  if (P == 0)
    t = (s == 0);
  else if (r == 0)
    t = (ISIGNF(P) >= s);
  else if (PDEG(P) == 0)
    t = VERIFYCONSTSIGN(r-1,PLDCF(P),s);
  else if (PDEG(P) % 2 == 1)
    t = 0;
  else 
    t = VERIFYCONSTSIGN(r-1,PLDCF(P),0) && VERIFYCONSTSIGN(r,PRED(P),s);

  return t;
}
