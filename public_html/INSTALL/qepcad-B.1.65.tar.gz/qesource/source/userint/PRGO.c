/*======================================================================
                      PRGO()

Process "go" command.
======================================================================*/
#include "qepcad.h"

void QepcadCls::PRGO()
{

Step1: /* Process. */
       PCNSTEP = 0;

Return: /* Prepare for return. */
       return;
}
