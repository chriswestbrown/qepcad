/*======================================================================
                         SETUPSYS()

Set up the System.
======================================================================*/
#include "saclib.h"
#include "qepcad.h"

/* $Format: "static char* version = \"$ProjectVersion$\";"$ */
static char* version = "1.6";

/* $Format: "static char* versdate = \"$ProjectDate$\";"$ */
static char* versdate = "Fri, 20 Sep 2002 18:15:58 -0400";

void setversline() {
  int j;
  SWRITE("QEPCAD Version B ");
  SWRITE(version);
  SWRITE(", ");
  for(j = 5; j < 16; j++)
    CWRITE(versdate[j]);
}

void SETUPSYS()
{

Step1: /* Initialize IO. */
       INITIO();

Step2: /* Identification. */
       SWRITE("=======================================================\n");
       SWRITE("     CAD2D - A Program for producing CADs of R^2       \n");
       SWRITE("                                                       \n");
       SWRITE("Based on ");setversline(); SWRITE(", by Hoon Hong\n");
       SWRITE("with contributions by: Christopher W. Brown, George E. \n");
       SWRITE("Collins, Mark J. Encarnacion, Jeremy R. Johnson        \n");
       SWRITE("Werner Krandick, Richard Liska, Scott McCallum,        \n");
       SWRITE("Nicolas Robiduex, and Stanly Steinberg                 \n");
       SWRITE("=======================================================\n");

Step3: /* Read in Help file. */
       HELPFRD();

Return: /* Prepare for return. */
       return;
}
   
   
