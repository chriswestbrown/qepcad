/*======================================================================
                      PRDCC()

Process "display candidate cells" command.
======================================================================*/
#include "saclib.h"
#include "qepcad.h"

void PRDCC()
{

Step1: /* Process. */
       SWRITE("Not implemented yet. \n");

Return: /* Prepare for return. */
       return;
}
