/*======================================================================
                      PRDPF()

Process "display projection factors" command.
======================================================================*/
#include "saclib.h"
#include "qepcad.h"

void PRDPF()
{

Step1: /* Display. */
       IPLLDWR(GVVL,GVPF); SWRITE("\n"); goto Return;

Return: /* Prepare for return. */
       return;
}
