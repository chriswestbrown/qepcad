/*===========================================================================
                       
===========================================================================*/
extern "C" {
#include <stdio.h>
#include "adj2D.h"
Word IBPPOS(Word A,Word a,Word b,Word e,Word k);
	   }

#include "rend.h"

void PLOT_2D_CAD(Word D, Word P, Word J)
{
  char c;
  Word N,e;
  Word i,j,I,ap,bp,a,b,L,p_n,n,A,Q,x,yl;

 Step1: /* Initialize. */
  cout << "Would you like to plot the CAD? (y/n): ";
  if (! (cin >> c && ( c == 'y' || c == 'Y')))
      return;
  Rend_Cell M;
  CONMIRCAD(D,P,J,M);
  
Step2: /* Plot loop. */
  do {
    Rend_Win W(M);
    W.set_precis_faithfull();
    W.update_extents(M);
    cout << "How many evaluation points? ";
    N = IREAD();
    e = LBRNP2PROD(LBRNDIF(W.X.W,W.x.W),-ILOG2(N));

Step3: /* Add the points. */
    for(i=1; i < M.child.size(); i += 2 ) { //-- loop over each sector
      I = M[i].sample -> coordinate( W.precis.x );
      FIRST2(I,&ap,&bp);
      a = LBRNRN(ap);  b = LBRNRN(bp);
      if (i == 1)
	a = RNDIF(a,LBRNRN(e)); //-- ensure that we draw to right edge.
      if (i == M.child.size() - 2)
	b = RNSUM(b,LBRNRN(e)); //-- ensure that we draw to right edge.
      for(L = SECOND(P); L != NIL; L = RED(L)) { //-- loop over each proj fac
	p_n = FIRST(L);
	n = THIRD( LELTI(p_n,PO_LABEL) );
	A = LELTI(p_n,PO_POLY);
	Q = IBPPOS(A,a,b,LBRNRN(e), W.precis.y); //- Must change to - k
	Q = CINV(Q);
	
Step4: /* Add new points to CAD. */
	while(Q != NIL) {
	  ADV2(Q,&yl,&x,&Q);
	  ADD_POINTS( M[i],n,x,yl ); } } }
	   
Step5: /* Write it. */
    char S[30];
    ofstream out;
    cout << "Filename: ";
    cin >> S;
    out.open(S);
    W.write_header(out);

    // Sectors over Sectors
    for(i = 1; i < M.child.size() - 1; i += 2) {
      for( j = 1; j < M[i].child.size() - 1; j+=2) {
	M[i][j].out_descrip(W,out); } }

    // Section and Cells over sections.
    for(i = 2; i < M.child.size() - 1; i += 2) {
      M[i].out_descrip(W,out);
      for( j = 1; j < M[i].child.size() - 1; j++) {
	M[i][j].out_descrip(W,out); } }

    // Sections over Sectors
    for(i = 1; i < M.child.size() - 1; i += 2) {
      for( j = 2; j < M[i].child.size() - 1; j+=2) {
	M[i][j].out_descrip(W,out); } }

    out.close();


    cout << "Would you like to plot more? (y/n): ";
  } while ( cin >> c && ( c == 'y' || c == 'Y' ) );

 
}

