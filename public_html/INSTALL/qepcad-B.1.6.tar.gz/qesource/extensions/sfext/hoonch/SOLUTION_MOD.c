/*======================================================================
                      SOLUTION(D,F,P,f; t,F_e,F_n,F_s)

Solution Formula Construction Phase - modified by chris.
It's modified to ignore the input formula.
 
\Input
  \parm{D} is a truth--invariant partial CAD.
  \parm{F} is the normalized quantifier-free  part of the input formula.
  \parm{P} is the list~$(P_1,\ldots,P_r)$, 
           where $P_i$ is the list of
           the $i$--level projection factors.
  \parm{f} is the number of free variables in the input formula.
 
\Output
  \parm{t}  is either \cn{equ} or \cn{inequ}.
  \parm{Fe} is a quantifier-free formula equivalent to
            the input formula if  $t$ is \cn{equ},
            otherwise $F_e$ is undefined.
  \parm{Fn} is a quantifier-free formula necessary for
            the input formula if $t$ is \cn{inequ},
            otherwise $F_n$ is undefined.
  \parm{Fs} is a quantifier-free formula sufficient for
            the input formula if $t$ is \cn{inequ},
            otherwise $F_s$ is undefined.
======================================================================*/
#include "saclib.h"
#include "qepcad.h"

void SOLUTION_MOD(D,F,P,f, t_,F_e_,F_n_,F_s_)
       Word D,F,P,f, *t_,*F_e_,*F_n_,*F_s_;
{
       Word F_e,F_n,F_s,T_c,T_f,T_t,Ths,Thss,t;
       /* hide Ths,Thss,t; */

Step1: /* Decision Problem. */
                                /*Int*/ Thss = ACLOCK();
       if (f > 0) goto Step2;
       t = EQU;
       if (LELTI(D,TRUTH) == TRUE)
         F_e = LIST4(EQOP,0,0,NIL);
       else
         F_e = LIST4(NEOP,0,0,NIL);
                               /*Int*/ Thss = ACLOCK() - Thss;
                               /*Int*/ TMSOLUTION = Thss;
       goto Return;

Step2: /* Signature tables. */
                               /*Int*/ Ths = ACLOCK();
       if (PCSIMPLIFY == 'b')         
         SIGTBL_MOD(D,f,NIL,NIL,&T_t,&T_f);
       else {
	 SWRITE("ERROR!  SOLUTION_MOD shouldn't get here!\n");
         FSIGTBL(D,f,NIL,NIL,&T_t,&T_f); }
       T_t = INV(T_t); T_t = RMDUP(T_t);
       T_f = INV(T_f); T_f = RMDUP(T_f);
                               /*Int*/ Ths = ACLOCK() - Ths;
                               /*Int*/ TMSIGTBL = Ths;
                               /*Int*/ NMPRPT = LENGTH(T_t);
                               /*Int*/ NMPRPF = LENGTH(T_f);

Step3: /* Any indistinguishable cell? */
                               /*Int*/ Ths = ACLOCK();
       T_c = SIGINS(T_t,T_f);
                               /*Int*/ Ths = ACLOCK() - Ths;
                               /*Int*/ TMSIGINS = Ths;
                               /*Int*/ NMPRPC = LENGTH(T_c);
       if (T_c == NIL)
          t = EQU;
       else
         { t = INEQU; goto Step5; }

Step4: /* $F_e$. */
       F_e = SIMPLIFY_MOD(T_t,T_f,F,P,f);
                               /*Int*/ Thss = ACLOCK() - Thss;
                               /*Int*/ TMSOLUTION = Thss;
       goto Return;

Step5: /* $F_n$. */
       F_n = SIMPLIFY(T_t,SIGSUB(T_f,T_c),F,P,f);

Step6: /* $F_s$. */
       F_s = SIMPLIFY(SIGSUB(T_t,T_c),T_f,F,P,f);
                               /*Int*/ Thss = ACLOCK() - Thss;
                               /*Int*/ TMSOLUTION = Thss;
       goto Return;

Return: /* Prepare for return. */
       *t_ = t;
       *F_e_ = F_e;
       *F_n_ = F_n;
       *F_s_ = F_s;

       return;
}
