/*======================================================================
                      Fh <- SIMPLIFY_MOD(T_t,T_f,F,P,f)

Simplify - modified, we assume that Tt and Tf represent all cells with
truth values TRUE or FALSE, and not just the propogation cells.

\Input
  \parm{Tt} is a list of distinct projection signatures. 
  \parm{Tf} is a list of distinct projection signatures.
            $T_t$ and $T_f$ are disjoint.
  \parm{F}  is the normalized quantifier-free part of 
            the input formula.
  \parm{P}  is the list $(P_1,\ldots,P_r)$ where $P_i$
            is the list of the $i$--level projection factors.
  \parm{f}  is the number of free variables.

\Output
  \parm{F^} is a quantifier-free formula.
            See the dissertation for the detail.
======================================================================*/
#include "saclib.h"
#include "qepcad.h"

Word SIMPLIFY_MOD(T_t,T_f,F,P,f)
       Word T_t,T_f,F,P,f;
{
       Word Fh,Fp,H,H_f,H_t,Th;

Step1: /* Use Bottom-up. */
       if (PCSIMPLIFY == 't') goto Step2;
       if      (T_t == NIL) 
          Fp = LIST4(NEOP,0,0,NIL); 
       else if (T_f == NIL)
          Fp = LIST4(EQOP,0,0,NIL); 
       else
         {
         H_t = SOPFST(T_t); H_f = SOPFST(T_f);
         H = MVLMA(H_t,H_f);
         Fp = QFFFSOP(H,P,f);
         }
       Fh = Fp;
       goto Return;

Step2: /* Use Top-down. */
       if      (T_t == NIL) 
          Fp = LIST4(NEOP,0,0,NIL); 
       else if (T_f == NIL)
          Fp = LIST4(EQOP,0,0,NIL); 
       else
         {
         H = ESPRESSO(T_t,T_f);
         Fp = QFFFSOP(H,P,f);
         }
       Fh = Fp;

Return: /* Prepare for return. */
       return(Fh);
}


