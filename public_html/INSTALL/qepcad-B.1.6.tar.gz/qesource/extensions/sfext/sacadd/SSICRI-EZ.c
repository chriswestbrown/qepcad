/*======================================================================
                      s <- SSICRI(a,b)

Smallest standard interval containing rational interval.

Inputs
      a : A rational number.
      b : A rational number, b > a, and sign(a) != -1 * sign(b).
Outputs
      s : A standard interval containing the interval (a,b).

======================================================================*/
#include "saclib.h"


Word SSICRIEZ(a_,b_)
       Word a_,b_;
{
       Word a,b,d,f,p,n,t1,t2,x,l,t,s;

Step0: /* Reflect interval if neccesary. */
       if (RNSIGN(a_) == -1) {
	 s = 1;
	 a = RNNEG(b_);
	 b = RNNEG(a_); }
       else {
	 s = 0;
	 a = a_;
	 b = b_; }

Step1: /* Set p to the smallest natural number s.t. 2^p >= a - b.  */
       d = RNDIF(b,a);
       RNFCL2(d,&f,&p); /* p = ceiling( log_2(d) ). */

Step2: /* Test if a standard interval of width 2^p 
	  exists containing (a,b). */
       x = RNP2(p);
       n = RNFLOR(RNQ(a,x));
       t1 = ISUM(n,1);
       if (p >= 0)
         t2 = RNINT(IMP2(t1,p));
       else
	 t2 = RNPROD(RNINT(t1),x);
       if (RNCOMP(t2,b) >= 1)
	 goto Return;
       else {
	 p++;
	 goto Step2; }

Return: /* Return, reflecting the output interval if needed. */
       if (s)
	 return (LIST2(RNNEG(t2),RNNEG(RNPROD(RNINT(n),x))));
       else
	 return (LIST2(RNPROD(RNINT(n),x),t2));
}
