/*======================================================================
                 NSFCONSTEI

Niave solution formula construction, enumerating implicants.

Inputs
 D :  A pruned CAD.
 P :  The projection factor data structure to which the signitures 
      of cells in D correspond.  This is a tricky point.  D is a pruned
      CAD, which means that each cell in D contains a reference to a
      cell in some CAD or RCAD structure.  This CAD or RCAD cell has
      a signiture structure, which should correspond to the structure
      P.  D is not sign invariant with respect to all polynomials in P,
      rather just a subset (let's call it P').  S is required to be
      contained in P'.
 S :  A subset of the projection factors which suffices for s.f. const.
      These factors should be given in the same data structure as the
      normal projection factor list.

Outputs
 SF:  A solution formula.

======================================================================*/
#include "saclib.h"
#include "qepcad.h"
static Word t1,t2,t3,n_I,n_SF;

Word NSFCONSTEI(D,P,S)
      Word D,P,S;
{
      Word Lt,Lf,L,T,c,SF,I,Sp,t,L_I;

Step1: /* Get the true and false lists. */
           t = ACLOCK();
      LTFOCWTV(D,&Lt,&Lf);
           t1 = ACLOCK() - t;

Step2: /* Find a set of prime implicants which covers the true cells. */
           t = ACLOCK();
      for(Sp = NIL; S != NIL; S = RED(S))
	Sp = CCONC(Sp,FIRST(S));
      L = NIL;
      for(T = Lt; T != NIL; T = PRUNECLPM(T,FIRST(L_I),P)) {
	ADV(T,&c,&T);
	L_I = APICONST(c,Lf,Sp,P);
	L = CCONC(L_I,L); }
           t2 = ACLOCK() - t; n_I = LENGTH(L);

Step3: /* Find a minimum cardinality subset of L which covers true cells. */
           t = ACLOCK();
      SF = WMINCOVBPI(Lt,L,P);
           n_SF = LENGTH(SF);
      switch (LENGTH(SF)) {
      case (0) : break;
      case (1) : SF = FIRST(SF); break;
      default: SF = COMP(OROP,SF); break; }
           t3 = ACLOCK() - t;
     
Return: /* Prepare to return. */
      return (SF);

}

void NSFCONSTEI_STATS()
{
      SWRITE("NSFCONST statistics:\n----------------------\n");
      SWRITE("Step 1 : "); IWRITE(t1); SWRITE(" miliseconds\n");
      SWRITE("Step 2 : "); IWRITE(t2); SWRITE(" miliseconds\n");
      SWRITE("Step 3 : "); IWRITE(t3); SWRITE(" miliseconds\n");
      SWRITE("Total time : "); IWRITE(t1+t2+t3); SWRITE(" miliseconds\n");
      SWRITE("Implicants were generated for "); IWRITE(n_I);
      SWRITE(" cells, and a formula \nwas generated using ");
      IWRITE(n_SF); SWRITE(" of these.\n----------------------\n");
      return;
}
