/*======================================================================
                 t <- EFIC(F,C,P)

Evaluate formula in cell.

Inputs
 F : A formula.
 C : A cell in a pruned CAD.
 P :  The projection factor set to which the signiture of C refers.

Outputs
 t : TRUE, FALSE, or UNDET.

======================================================================*/
#include "saclib.h"
#include "qepcad.h"
#include "coarsecad.h"

Word EFIC(F,C,P)
      Word F,C,P;
{
      Word O,Fp,A,t_A,t_Fp,t;

Step1: /* F is an atomic formula. */
      if (ISLIST(FIRST(F))) { t = EAFIC(F,C,P); goto Return; }

Step2: /* Get componant truth values. */
      ADV(F,&O,&Fp);
      ADV(Fp,&A,&Fp);
      t_A = EFIC(A,C,P);
      if (LENGTH(Fp) == 1) 
	t_Fp = EFIC(FIRST(Fp),C,P);
      else
	t_Fp = EFIC(COMP(O,Fp),C,P);

Step3: /* Determine truth value from componant truth values. */
      t = UNDET;
      if (O == OROP) {
	if ((t_A == TRUE) || (t_Fp == TRUE)) t = TRUE;
	if ((t_A == FALSE) && (t_Fp == FALSE)) t = FALSE; }
      else {
	if ((t_A == FALSE) || (t_Fp == FALSE)) t = FALSE;
	if ((t_A == TRUE) && (t_Fp == TRUE)) t = TRUE; }

Return: /* Prepare to return. */
      return (t);
}
