/*======================================================================
                 t <- EAFIC(A,C,PF)

Evaluate atomic formula in cell.

Inputs
 A : An atomic formula.
 C : A cell in a pruned CAD.
 PF:  The projection factor set to which the signiture of C refers.

Outputs
 t : TRUE, FALSE, or UNDET.

======================================================================*/
#include "saclib.h"
#include "qepcad.h"
#include "coarsecad.h"

Word EAFIC(A,C,PF)
      Word A,C,PF;
{
      Word P,R,i,j,c,l,S,S_i,k,s,t,I,jp;

Step1: /* Get atomic formula information. */
      FIRST2(A,&P,&R);
      I = RED(LELTI(P,PO_LABEL));
      FIRST2(I,&i,&j);
      jp = PFPIPFL(P,LELTI(PF,i));

Step2: /* Get cell information. */
      c = LELTI(C,SC_REP);
      l = LENGTH(LELTI(c,INDX));
      if (l < i) {
	t = UNDET;
	goto Return; }
      S = LELTI(c,SIGNPF);
      S_i = LELTI(S,l - i + 1);
      s = LELTI(S_i,jp);

Step3: /* Compare sign of cell on pol. to relational op. */
      switch (R) {
      case (LTOP) : t = (s <  0); break;
      case (EQOP) : t = (s == 0); break;
      case (GTOP) : t = (s >  0); break;
      case (GEOP) : t = (s >= 0); break;
      case (NEOP) : t = (s != 0); break;
      case (LEOP) : t = (s <= 0); break; }

Return: /* Prepare to return. */
      return (t);
}
