/*======================================================================
                      DIELOC()

Display Input Error Location.

Remarks
  This dummy does not do anything, yet.
======================================================================*/
#include "saclib.h"

void DIELOC()
{
Step1: /* Don't do anything. */
       return;
}
