extern "C" {
#include "saclib.h"
void GCSI(Word s, char *EACSTACK);
};
