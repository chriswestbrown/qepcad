/* Define two positions new to the RCell. */
#define INCELL 11
#define OSPFLAG 12
