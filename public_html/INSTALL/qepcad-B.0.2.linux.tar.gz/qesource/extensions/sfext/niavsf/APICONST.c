/*======================================================================
                 L_I <- APICONST(c,L,S,P)

all prime implicant construct.

Inputs
 c :  A pruned CAD cell with truth value true.
 L :  A list of puned CAD cells with truth values false.
 S :  A subset of the projection factors which suffices for s.f. const.
 P :  The projection factor data structure to which the signiture
      of c refers.
 
Outputs
 I :  A list of all conjunctions of atomic formulae over S which 
      captures c, but none of L.

======================================================================*/
#include "saclib.h"
#include "qepcad.h"

Word APICONST(c,L,S,P)
      Word c,L,S,P;
{
      Word L_A,Sp,T,Q,f,L_f,t,Is,I,Lp,i,L_I,L_Is;

Step1: /* Construct list of atomic formula from which I will be constructed. */
      L_A = NIL;
      for(Sp = S; Sp != NIL; Sp = RED(Sp)) {
	T = EAFOPSIC(c,FIRST(Sp),P);
	L_A = CCONC(L_A,T); }

Step2: /* Construct a list with an element for every cell in L.  That element
	  will be a list of all the atomic formula (given by their position
	  in L_A, which the cell does not satisfy. */
      Q = NIL;
      for(Lp = L; Lp != NIL; Lp = RED(Lp)) {
	f = FIRST(Lp);
	L_f = NIL; i = 1;
	for(T = L_A; T != NIL;i++) {
	  ADV(T,&t,&T);
	  if (EAFIC(t,f,P) == FALSE)
	    L_f = COMP(i,L_f); }
	Q = COMP(INV(L_f),Q); }

Step3: /* Find a min hit set for Q, and construct prime implicant from it. */
      L_Is = ENUMMINHITSETSRDR(Q,-1);
      for(L_I = NIL; L_Is != NIL; L_Is = RED(L_Is)) {
	Is = FIRST(L_Is);
	for(I = NIL; Is != NIL; Is = RED(Is))
	  I = COMP(LELTI(L_A,FIRST(Is)),I); 
	switch ( LENGTH(I) ) {
	case (0) : break;
	case (1) : I = FIRST(I); break;
	default :  I = COMP(ANDOP,I); break; }
	L_I = COMP(I,L_I); }

Return: /* Return. */
      return (L_I);

}
