/*======================================================================
                     t <- SIGEQUALOL(A,B,L)

Sign equal on list.

inputs
 A : An array on 0's 1's and '-1's of length a.
 B : An array on 0's 1's and '-1's of length b.
 L : A list of non-negative BETA-Digits, each less than min(a,b).

outputs
 t : 1 if A[i] = B[i] for each i in L, and 0 otherwise.
======================================================================*/
#include "saclib.h"
#include "qepcad.h"


Word SIGEQUALOL(A,B,L)
      Word *A,*B,L;
{

Step1: /* The only step! */
      while ( (L != NIL) && (A[ FIRST(L) ] == B[ FIRST(L) ]) )
	L = RED(L);

Return:/* Return. */
      return (L == NIL);
}

