/*

Set truth value to formula.

*/

#include "espcad.h"


void SETTV2FMA(D,P,F)
       Word D,P,F;
{
  Word Ds,EDs;
  Ds = SCADDSCON(D,NIL,GVNFV);
  EDs = PCAD2ESPCAD(P,P,Ds,NIL);
  SETMARK2FMA(EDs,F,P);
  SETCADTV2MARK(EDs);
  return;
}

