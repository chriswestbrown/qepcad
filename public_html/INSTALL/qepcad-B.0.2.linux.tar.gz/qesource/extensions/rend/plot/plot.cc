extern "C"{
#include "srgp.h"
	  }

#include <stream.h>

extern "C" {
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
	   }
#include <string.h>
#include <fstream.h>

// #define _BUG_


/*****************************************************************
******  main function for plotting program.
******************************************************************/
int main(int argc, char* argv[])
{
  
  /***************************************
  ** Check for argument given!
  ****************************************/
  if (argc < 2) {
    cerr << "No arguments given.  A pipe name is required." << endl;
    exit(1); }
  
  /***************************************
  ** Attempt to open input pipe.
  ****************************************/
  ifstream in;
  in.open(argv[1]);
  if (!in) {
    cerr << "Couldn't open input pipe." << endl;
    exit(1); }
  
  /***************************************
  ** declare variables.
  ****************************************/
  char c;
  int d1,d2,x,y,X[2000],Y[2000];
  int i,n,flag;
  
  /***************************************
  ** read in window size.  Window is not allowed to be larger than
  ** 1000x1000, and the arrays winX and winY are defined to contain
  ** the coordinates of the window corners.
  ****************************************/
  in >> d1 >> d2; 
#ifdef _BUG_
  cerr << "Read " << d1 << " x " << d2 << endl;
#endif
  d1 = d1 > 1000 ? 1000 : d1;
  d2 = d2 > 1000 ? 1000 : d2;
  int winX[4]; winX[0] = 0; winX[1] = d1; winX[2] = d1; winX[3] = 0;
  int winY[4]; winY[0] = 0; winY[1] = 0; winY[2] = d2; winY[3] = d2;

  
  /***************************************
  ** SRGP initialization.  
  ****************************************/
  SRGP_begin("ADJ2D_Plot",d1,d2,5,0);
  SRGP_setKeyboardProcessingMode(RAW);
  SRGP_setInputMode(KEYBOARD, EVENT);
  SRGP_setLineWidth(2);
  

  /***************************************
  ** Colors!!
  ****************************************/
  int T_d2 = 4,
      F_d2 = 5,
      U_d2 = 6,
      T_d1 = 7,
      F_d1 = 8,
      U_d1 = 9;
  SRGP_loadCommonColor(T_d2,"DarkSeaGreen2");
    SRGP_loadCommonColor(F_d2,"PaleGoldenrod");
    SRGP_loadCommonColor(U_d2,"gainsboro");
    SRGP_loadCommonColor(T_d1,"ForestGreen");
    SRGP_loadCommonColor(F_d1, "DarkKhaki");
    SRGP_loadCommonColor(U_d1,"SlateGrey");
  
  /***************************************
  ** The big LOOP!! Keep going 'till E is recieved.
  ****************************************/
  do {
    flag = 1;
    
    /***************************************
    ** The little LOOP!! Keep going for each new object.
    ****************************************/
    while( in >> c ) {
#ifdef _BUG_
      cerr << "Read a ... " << c << endl;
#endif
      /************************* Repaint the background. ***/
      if (flag && c != 'E') {
	flag = 0;
	SRGP_setColor(U_d2);
	SRGP_fillPolygonCoord(4,winX,winY); }
   
	
      /************************* The big SWITCH which object do I have? **/
      switch(c) {
	
      case 'L': /**** 2D section over sector. *****/
	/******************************************/
	if ( (in >> c) && ( c == 'T') )
	  SRGP_setColor(T_d1);
	else if (c == 'F')
	  SRGP_setColor(F_d1);
	else
	  SRGP_setColor(U_d1);
	for(in >> n, i = 0; i < n; i++) {
	  in >> X[i] >> Y[i];
#ifdef _BUG_
	  cerr<<X[i]<<'\t'<<Y[i]<<endl;
#endif
	}
	SRGP_polyLineCoord(n,X,Y);
	break;
	
      case 'P': /**** 2D sector 0ver sector********/
	/******************************************/
	if ( (in >> c) && ( c == 'T') )
	  SRGP_setColor(T_d2);
	else if (c == 'F')
	  SRGP_setColor(F_d2);
	else
	  SRGP_setColor(U_d2);
	for(in >> n, i = 0; i < n; i++)
	  in >> X[i] >> Y[i];
	if (n > 2) SRGP_fillPolygonCoord(n,X,Y);
	break;
	
	
      case 'R': /**** 2D sector 0ver section. *****/
	/******************************************/
	if ( (in >> c) && ( c == 'T') )
	  SRGP_setColor(T_d1);
	else if (c == 'F')
	  SRGP_setColor(F_d1);
	else
	  SRGP_setColor(U_d1);
	in >> X[0] >> Y[0] >> Y[1];
	X[1] = X[0];
	SRGP_polyLineCoord(2,X,Y);
	break;
	
      case 'V': /***** 1D section *****************/
	/******************************************/
	if ( (in >> c) && ( c == 'T') )
	  SRGP_setColor(T_d1);
	else if (c == 'F')
	  SRGP_setColor(F_d1);
	else
	  SRGP_setColor(U_d1);
	in >> X[0];
	X[1] = X[0];
	Y[0] = 0;
	Y[1] = d2;
	SRGP_polyLineCoord(2,X,Y);
	break;
	
      case 'C': /***** 1D sector  *****************/
	/******************************************/
	if ( (in >> c) && ( c == 'T') )
	  SRGP_setColor(T_d2);
	else if (c == 'F')
	  SRGP_setColor(F_d2);
	else
	  SRGP_setColor(U_d2);
	in >> X[0] >> X[1];
	X[2] = X[1];
	X[3] = X[0];
	Y[0] = 0; Y[1] = 0; Y[2] = d2; Y[3] = d2; 
	SRGP_fillPolygonCoord(4,X,Y);
	break;
	
      case 'S': /****** 2D section over section. **/
	/******************************************/
	if ( (in >> c) && ( c == 'T') )
	  SRGP_setColor(T_d1);
	else if (c == 'F')
	  SRGP_setColor(F_d1);
	else
	  SRGP_setColor(U_d1);
	in >> X[0] >> Y[0];
	SRGP_markerCoord(X[0],Y[0]);
	break;
	
      case 'F': /******* Refresh it! **************/
	/******************************************/
	SRGP_refresh();
	flag = 1;
	break;

      case 'E': /******* Print it! ****************/
	/******************************************/
	goto done;
      }
    }

#ifdef _BUG_
    cerr << "Closing pipe!" << endl;
#endif
    in.close();
    in.open(argv[1]);
  }while(1);

 done:

#ifdef _BUG_
  cerr << "Closing pipe for good!" << endl;
#endif
  in.close();
  SRGP_waitEvent(-1);

  SRGP_end();
}

/*
g++ plot.cc -o ADJ2D_plot -fpcc-struct-return \
-I/home/wcbrown/graphics/SRGP_DISTRIB/include \
-I/usr/include/X11 \
/home/wcbrown/graphics/SRGP_DISTRIB/lib/libsrgp.a \
/usr/lib/libX11.so -lm \
-lsocket -lnsl -lresolv
*/

