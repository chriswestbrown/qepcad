/*======================================================================
                      PRDPJ()

Process "display projection polynomials" command.
======================================================================*/
#include "saclib.h"
#include "qepcad.h"

void PRDPJ()
{

Step1: /* Display. */
       IPLLDWR(GVVL,GVPJ); SWRITE("\n"); goto Return;

Return: /* Prepare for return. */
       return;
}
