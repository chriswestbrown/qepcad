/*======================================================================
                      PRPROPEC()

Process prop-eqn-const command.
======================================================================*/
#include "saclib.h"
#include "qepcad.h"

void PRPROPEC()
{
       Word C,i,r;

Step1: /* Toggle the PCPROPEC global variable and initialize globals. */
       GVEQNCONST = GVPIVOT = NIL;
/* Chris Added. */ GVEQN2A = NIL;
       if (PCPROPEC == FALSE) {
	 PCPROPEC = TRUE;
	 r = LENGTH(GVVL);
	 for (i = 1; i <= r; i++) {
	   GVEQNCONST = COMP(NIL,GVEQNCONST);
	   GVPIVOT = COMP(NIL,GVPIVOT); } }
       else
	 PCPROPEC = FALSE;

Return: /* Prepare for return. */
       return;
}
