/*===========================================================================
                         PREQNCONSTL()

Process eqn-const-list command.
===========================================================================*/
#include "saclib.h"
#include "qepcad.h"

void PREQNCONSTL()
{

       Word i,j,t,E,k,L,Lp,L1;

Step1: /* Check if propagation of equational constraints was specified. */
       if (PCPROPEC == FALSE) {
	  SWRITE("Error PREQNCONSTL: \"prop-eqn-const\" was not issued.\n");
	  goto Return; }

Step2: /* Read in argument of the form "(A_i,j,...,A_m,n)". */
       L = NIL;
       k = 0;
       if (CREADB() != '(') {
	  SWRITE("Error PREQNCONSTL: '(' was expected.\n");
	  goto Step5; }
       do {
	  if (CREADB() != 'A') {
	     SWRITE("Error PREQNCONSTL: 'A' was expected.\n");
	     goto Step5; }
	  if (CREADB() != '_') {
	     SWRITE("Error PREQNCONSTL: '_' was expected.\n");
	     goto Step5; }
	  GREADR(&i,&t); if (t == 0) goto Return;
	  if (i > k) k = i;
	  if (CREADB() != ',') {
	     SWRITE("Error PREQNCONSTL: ',' was expected.\n");
	     goto Step5; }
	  GREADR(&j,&t); if (t == 0) goto Return;
	  if (LKAHEAD() == ',') CREADB();
	  L = COMP(MKLABEL("A",i,j),L); }
       while (LKAHEAD() != ')');
       L = INV(L);
       CREADB();

Step3: /* Check validity of labels. */
       Lp = L;
       while (Lp != NIL) {
	  ADV(Lp,&L1,&Lp);
	  if (VALIDLBL(L1) != TRUE) {
	     SWRITE("Error PREQNCONSTL: ");
	     LABELWR(FIRST(L1),RED(L1));
	     SWRITE(" -- No such polynomial.\n");
	     goto Return; }
	  if (LBLLEVEL(L1) > GVLV) {
	     SWRITE("Error PREQNCONSTL: ");
	     SWRITE("Declared constraint is of too high a level.\n");
	     goto Return; } }

Step4: /* Update list of equational constraints. */
       E = LELTI(GVEQNCONST,k);
       if (E == NIL)
	  SLELTI(GVPIVOT,k,L);
       E = SUFFIX(E,L);
       SLELTI(GVEQNCONST,k,E);
       goto Return;
       
Step5: /* Input error. */
       DIELOC();

Return: /* Prepare for return. */
       return;
}
