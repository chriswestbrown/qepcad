/*======================================================================
                      PRDF()

Process "display formula" command.
======================================================================*/
#include "saclib.h"
#include "qepcad.h"

void PRDF()
{

Step1: /* Process. */
       FWRITE(GVVL,GVF); SWRITE("\n");

Return: /* Prepare for return. */
       return;
}
