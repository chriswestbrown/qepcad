/*======================================================================
                      PRESPFWR()

Process "Espresso Full Signature Tables Write" command.
======================================================================*/
#include "saclib.h"
#include "qepcad.h"

void PRESPFWR()
{
       Word T_f,T_t;

Step1: /* Take tables. */
       FSIGTBL(GVPC,GVNFV,NIL,NIL,&T_t,&T_f);
       T_t = INV(T_t); T_t = RMDUP(T_t);
       T_f = INV(T_f); T_f = RMDUP(T_f);

Step2: /* Write. */
       ESPIWR(T_t,T_f);

Return: /* Prepare for return. */
       return;
}
