/*======================================================================
                 L <- PRUNECLPM(T,I,P)

Prune cell list by prime implicant.

Inputs
 T :  A a list of pruned CAD cells.
 I :  A prime implicant.
 P :  The projection factor set to which the signiture of the cells refer.

Outputs
 L :  A list of all pruned CAD cells in T which do not satisfy I. L is
      a sublist of T, i.e. order is preserved.

======================================================================*/
#include "saclib.h"
#include "qepcad.h"

Word PRUNECLPM(T,I,P)
      Word T,I,P;
{
      Word L,c;

Step1: /* Construct L. */
      for(L = NIL; T != NIL; T = RED(T)) {
	c = FIRST(T);
	if (EFIC(I,c,P) != TRUE)
	  L = COMP(c,L); }
      L = INV(L);

Return: /* Return. */
      return (L);

}
