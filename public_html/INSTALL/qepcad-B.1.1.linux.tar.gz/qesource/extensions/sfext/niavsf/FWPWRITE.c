/*======================================================================
                 FWPWRITE(F)

Formula with polynomial write.

Inputs
 F : A formula.
Side Effects
 F is written to standard out, using the actual polynomial.

======================================================================*/
#include "saclib.h"
#include "qepcad.h"

void FWPWRITE(F)
      Word F;
{
      Word O,Fp,A,V,r,t;

Step1: /* F is an atomic formula. */
      if (FTYPEINFO(F) == NIL) {
	r = LELTI(LELTI(FIRST(F),PO_LABEL),2);
	for(V = CINV(GVVL); LENGTH(V) > r; V = RED(V));
	IPDWRITE(r,LELTI(FIRST(F),PO_POLY),INV(V));
	switch(SECOND(F)) {
	case (LTOP) : SWRITE(" < 0"); break;
	case (LEOP) : SWRITE(" <= 0"); break;
	case (GTOP) : SWRITE(" > 0"); break;
	case (GEOP) : SWRITE(" >= 0"); break;
	case (EQOP) : SWRITE(" = 0"); break;
	case (NEOP) : SWRITE(" /= 0"); break; }
	goto Return; }

Step2: /* F is a disjunction or conjunction. */
      ADV(F,&O,&Fp);
      do {
	ADV(Fp,&A,&Fp);
	t = FTYPEINFO(A);
	if (t != NIL && t != O) { SWRITE("[ "); FWPWRITE(A); SWRITE(" ]"); }
	else FWPWRITE(A);
      if (Fp == NIL) break;
	if (O == OROP)  SWRITE(" \\/ ");
	if (O == ANDOP) SWRITE(" /\\ ");
      } while(1);

Return: /* Prepare to return. */
      return;
}

