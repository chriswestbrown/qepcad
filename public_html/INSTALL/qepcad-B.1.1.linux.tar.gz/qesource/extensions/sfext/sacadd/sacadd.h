Word ILBRN(Word I);
Word LAST(Word L);
Word LBRNFIE(Word I,Word e);
Word LBRNP2PROD(Word r,Word k);
Word LBRNQORD(Word A,Word B);
Word SSICRIEZ(Word a_,Word b_);
Word SSICRI(Word a_,Word b_);
Word SSILRICRI-EZ(Word a_,Word b_);
Word SSILRCRI(Word a_,Word b_);
