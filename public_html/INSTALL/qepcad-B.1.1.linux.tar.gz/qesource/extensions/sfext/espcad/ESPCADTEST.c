/*
Test ESPCAD Functions.
 */


#include "espcad.h"

static Word F(Word L)
{
  Word Lp,J,g,f;
  J = NIL;
  g = NIL;
  for(Lp = L; Lp != NIL; Lp = RED(Lp)) {
    f = FIRST(Lp);
    if (g == NIL) {
      if (ISATOM(SECOND(f))) {
	J = COMP(f,J);
	g = f; } }
    else {
      if (ISATOM(SECOND(f)) && 
	  (! EQUAL(FIRST(f),FIRST(g)) || SECOND(f) < SECOND(g)) ) {
	J = COMP(f,J);
	g = f; } } }
  return J;
}

void ESPCADTEST()
{
  Word D,P,n,Dp,Dpp,Lt,Lf,L,Lp;

  D = GVPC;
  P = GVPF;

  SWRITE("Input the highest level allowed in ESPCAD: ");
  n = IREAD();

  Dp = SCADDSCON(D,NIL,n);
  Dpp = PCAD2ESPCAD(P,P,Dp,NIL);
  SWRITE("\n");

  LTFOCWTV(Dpp,&Lt,&Lf);

  TESTCELL(Lt,Lf,P,n);

  return;
}
