
#include "extlang.h"

static Word curr_k;
static Word comparek(Word, Word);

Word ESCADTEST(P,C)
       Word P,C;
{
  Word Cs,ECs,L,l,Q,Lp,q,CL,T,F,f1,f2,k,A,Ak;
  Cs = SCADDSCON(C,NIL,GVNFV);
  ECs = SCAD2ESCAD(P,P,Cs,NIL);

  A = NIL;

  for(k = GVNFV; k > 0; k--) {
    curr_k = k;
    F = NIL;

    SWRITE("Level "); IWRITE(k); SWRITE(":\n");

    for(CL = ESCADCL(ECs,k-1); CL != NIL; CL = RED(CL)) {
      SWRITE("Over cell "); 
      OWRITE(LELTI(LELTI(FIRST(CL),SC_REP),INDX)); 
      SWRITE("\n");

      L = CELLDSORT(LIST1(FIRST(CL)));
      
      Q = NIL; 
      for(Lp = L; Lp != NIL; Lp = RED(Lp)) {
	T = ESCCPLIST1(FIRST(Lp),k);
	F = CONC(ESCMHSCONST1(T,FIRST(CL),k),F);
	Q = CONC(T,Q); }
      
      SWRITE("Conflicting pairs:\n");
      while(Q != NIL) {
	ADV(Q,&q,&Q);
	ESCELLWR(FIRST(q));
	ESCELLWR(SECOND(q));
	SWRITE("\n"); } }

    SWRITE("\n\n"); OWRITE(F); SWRITE("\n\n");
    F = ESCMINHITSET(F);
    SWRITE("\n\n"); OWRITE(F); SWRITE("\n\n");
    
    Ak = NIL;
    while (F != NIL) {
      FIRST2(FIRST(F),&f1,&f2);
      ADDROOTKFUNC(k,f1,f2,ECs);
      Ak = COMP(LIST3(k,f1,f2),Ak);
      F = RED(F); }
    A = COMP(Ak,A); }

  escadfcons(ESCADCL(ECs,GVNFV),P,A,GVNFV);

if (GVNFV < 0)
  TEMPWR(0,0);
      
  return 1;
}       



static Word comparek(Word A, Word B)
{
  Word a1,a2,b1,b2,ia1,ia2,ib1,ib2,t;
  FIRST2(A,&a1,&a2);
  FIRST2(B,&b1,&b2);
  ia1 = LELTI(LELTI(LELTI(a1,SC_REP),INDX),curr_k);
  ia2 = LELTI(LELTI(LELTI(a2,SC_REP),INDX),curr_k);
  ib1 = LELTI(LELTI(LELTI(b1,SC_REP),INDX),curr_k);
  ib2 = LELTI(LELTI(LELTI(b2,SC_REP),INDX),curr_k);
  t = ICOMP(ia1,ib1);
  return (t != 0) ? t : ICOMP(ia2,ib2);
}
