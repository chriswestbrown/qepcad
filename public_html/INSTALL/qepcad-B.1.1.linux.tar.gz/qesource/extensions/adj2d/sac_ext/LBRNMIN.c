/*======================================================================
                      c <- LBRNMIN(a,b)

Logarithmic binary rational number min.

Inputs
  a, b : logarithmic binary rational numbers.

Outputs
  c : a logarithmic binary rational number.  c = min(a,b).
======================================================================*/
#include "saclib.h"

Word LBRNMIN(a,b)
       Word a,b;
{
       Word c;

Step1:
       if (LBRNCOMP(a,b) <= 0)
         c = a;
       else
         c = b;

Return:
       return(c);
}
