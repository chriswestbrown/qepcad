/******************************************
 ** Header file for 2D lifting extensions
 ******************************************/
#ifndef _LIFT2D_
#define _LIFT2D_

#include "saclib.h"
#include "qepcad.h"

void IBPRRIOAP(Word M,Word I,Word B,Word k, Word *L_,BDigit *t_);
Word PFSRRQ2D(Word p,Word *L_);
Word CELLSRRQ2D(Word c, Word P);
Word CELLLEFTSIB(Word c, Word D);
Word CELLRIGHTSIB(Word c, Word D);
Word LIFTSRR2D(Word c, Word D, Word P);


#endif /* _LIFT2D_ */
