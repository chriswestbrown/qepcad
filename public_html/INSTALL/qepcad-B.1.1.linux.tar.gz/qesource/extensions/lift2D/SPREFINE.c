/*======================================================================
                      SPREFINE

Sample Point Refine Half Assed Version!

Inputs
  

Outputs

======================================================================*/


/* Sample Point is 
