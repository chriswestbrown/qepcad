/*======================================================================
                      PRDNQFF()

Process "display normalized quantifier-free part of the input formula"
command.
======================================================================*/
#include "saclib.h"
#include "qepcad.h"

void PRDNQFF()
{

Step1: /* Process. */
       QFFWR(GVVL,GVNQFF); SWRITE("\n"); goto Return;

Return: /* Prepare for return. */
       return;
}
