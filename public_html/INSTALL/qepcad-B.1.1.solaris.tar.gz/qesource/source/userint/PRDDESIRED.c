/*======================================================================
                      PRDDESIRED()

Process "display the condition for desired cell" command.
======================================================================*/
#include "saclib.h"
#include "qepcad.h"

void PRDDESIRED()
{

Step1: /* Process. */
       SWRITE("The condition for desired cells: "); 
       DESIREDWR(PCDESIRED);
       SWRITE("\n");
       SWRITE("This condition is currenly ");
       if (PCUSEDES == 'y') 
         SWRITE("ACTIVE.\n");
       else
         SWRITE("INACTIVE.\n");

Return: /* Prepare for return. */
       return;
}
