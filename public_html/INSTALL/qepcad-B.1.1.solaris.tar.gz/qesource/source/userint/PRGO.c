/*======================================================================
                      PRGO()

Process "go" command.
======================================================================*/
#include "saclib.h"
#include "qepcad.h"

void PRGO()
{

Step1: /* Process. */
       PCNSTEP = 0;

Return: /* Prepare for return. */
       return;
}
