/*************************************************************
 **
 **  Mapper.h
 **
 **  A Mapper object represents a mapping taking points from
 **  some rectangle [x,X]x[y,Y], where x,X,y,Y are logarithmic
 **  binary rational numbers, (this is the "view rectangle")
 **  and mapping them to the rectangle [x1,x2]x[y1,y2] (this
 **  is the "rend"rectangle).
 **
 *************************************************************/
#ifndef _MAPPER_
#define _MAPPER_
#include "saclib.h"
#include "gcmemloc.h"
#include "Rend_Win.h"
#include <iomanip.h>
#include <math.h>

class Rend_Win;

class Mapper
{
 private:
  gcmemloc Sx, Kx, Sy, Ky;
 public:
  Mapper(int x1, int y1, int x2, int y2, Rend_Win &W)
  {
    Sx.W = RNQ(RNINT(x2 - x1),LBRNRN(LBRNDIF(W.X.W,W.x.W)));
    Kx.W = RNDIF(RNINT(x1),RNPROD(Sx.W,LBRNRN(W.x.W)));

    Sy.W = RNQ(RNINT(y2 - y1),LBRNRN(LBRNDIF(W.Y.W,W.y.W)));
    Ky.W = RNDIF(RNINT(y1),RNPROD(Sy.W,LBRNRN(W.y.W)));

  }
  Word mapX(Word r)
  {
    return RNSUM(RNPROD(Sx.W,LBRNRN(r)),Kx.W);
  }
  Word mapY(Word r)
  {
    return RNSUM(RNPROD(Sy.W,LBRNRN(r)),Ky.W);
  }
  void Xwrite(Word r, ostream &out, int p)
  {
    Word A,Ap;
    A = mapX(r);
    out << setprecision(p);
    Ap = RNPROD(A,RNP2(p));
    out << double(RNFLOR(Ap)) / pow(2,p);
  }
  void Ywrite(Word r, ostream &out, int p)
  {
    Word A,Ap;
    A = mapY(r);
    out << setprecision(p);
    Ap = RNPROD(A,RNP2(p));
    out << double(RNFLOR(Ap)) / pow(2,p);
  }
  void Pwrite(Word r, ostream &out, int p)
  {
    Word x,y;
    FIRST2(r,&x,&y);
    Xwrite(x,out,p);
    out << " ";
    Ywrite(y,out,p);
  }
  void LPwrite(Word L, ostream &out, int p, int flag = 0)
  {
    out << "newpath\n";
    Pwrite(FIRST(L),out,p);
    out << " moveto\n";
    for(L = RED(L); L != NIL; L = RED(L)) {
      Pwrite(FIRST(L),out,p);
      out << " lineto\n"; }
    if (flag)
      out << "fill" << endl;
    else
      out << "stroke" << endl;
  }
};


#endif /* _MAPPER_ */
