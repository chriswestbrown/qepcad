/*======================================================================
                      l <- LAST(L)

Last element.

Inputs
  L  : a non-empty list.
  
Outputs
  l  : the last element of L.
======================================================================*/
#include "saclib.h"

Word LAST(L)
      Word L;
{
      Word l;

Step1: /* Compute. */
      for(ADV(L,&l,&L); L != NIL; ADV(L,&l,&L));

Return: /* Prepare to return. */
      return(l);
}
