/*======================================================================
                 L <- EAFOPSIC(C,P,PF)

Enumerate atomic formulae on polynomial P which are satisfied in cell c.

Inputs
 C :  A pruned CAD cell.
 P :  A projection factor.
 PF:  The projection factor set to which the signiture of C refers.
 
Outputs
 L :  A list of atomic formula on P which are satisfied in c.

======================================================================*/
#include "saclib.h"
#include "qepcad.h"
#include "coarsecad.h"

Word EAFOPSIC(C,P,PF)
      Word C,P,PF;
{
      Word I,i,j,c,l,L,S,S_i,s,k,jp;

Step1: /* Get cell index and polynomial index. */
      I = RED(LELTI(P,PO_LABEL));
      FIRST2(I,&i,&j);
      c = LELTI(C,SC_REP);
      l = LENGTH(LELTI(c,INDX));

Step2: /* If level of P is greater than level c, return empty list. 
	  Otherwise, get the sign of P in c. */
      if (l < i) {
	L = NIL;
	goto Return; }
      jp = PFPIPFL(P,LELTI(PF,i));
      S = LELTI(c,SIGNPF);
      S_i = LELTI(S,l - i + 1);
      s = LELTI(S_i,jp);

Step3: /* Generate the right list of atomic formulae, based on the value of s. */
      switch (s) {
      case (1) : L = LIST3(LIST2(P,NEOP),LIST2(P,GEOP),LIST2(P,GTOP)); break;
      case (0) : L = LIST3(LIST2(P,GEOP),LIST2(P,LEOP),LIST2(P,EQOP)); break;
      case (-1) : L = LIST3(LIST2(P,NEOP),LIST2(P,LEOP),LIST2(P,LTOP)); break; }
      
Return: /* Return. */
      return (L);

}
