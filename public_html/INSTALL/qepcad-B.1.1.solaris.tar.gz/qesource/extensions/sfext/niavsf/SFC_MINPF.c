#include "saclib.h"
#include "qepcad.h"

void SFC_MINPF()
{
      Word t0,t1,t2,t3,Ps,Ds,Q,SF,C,i,D,P;

D = GVPC; P = GVPF; 

/* TIME */ t0 = ACLOCK();
Step0: /* Check for the trivial cases. */
      switch( DOPFSUFF(P,LIST1(D)) ) {
      case (TRUE) : SWRITE("\n\nInput is identically TRUE.\n\n");
	            goto Return;
      case (FALSE): SWRITE("\n\nInput is identically FALSE.\n\n");
	            goto Return; 
      case (NIL)  : SWRITE("\n\nThe projection set does not suffice.\n\n");
	            goto Return; }
/* TIME */ t0 = ACLOCK() - t0;
 
/* TIME */ t1 = ACLOCK();
Step1: /* Find some polynomials which we know will pop up in Q. */
      Q = PWUDSCWCP(D,P,GVNFV);
/* TIME */ t1 = ACLOCK()-t1;

Step2: /* Find a minimal set of polynomials which suffice for SF const,
	  making use of the set Q computed in Step 1. */
/* TIME */ t2 = ACLOCK();
      Q = MINPFSET(P,Q,D);
/* TIME */ t2 = ACLOCK()-t2;

Step3: /* Construct a CAD from the proj-closure of Qs from step2. */
/* TIME */ t3 = ACLOCK();
      CCADCONFPFS(GVNFV,P,D,Q,&Ps,&Ds);
/* TIME */ t3 = ACLOCK()-t3;

/* STAT */ SWRITE("\nSolution formula construction preprocessing time: ");
           IWRITE(t0); SWRITE(", ");
           IWRITE(t1); SWRITE(", ");
           IWRITE(t2); SWRITE(", ");
           IWRITE(t3); SWRITE("\n");


Step4: /* Construct that solution formula. */
      SF = NSFCONSTEI(Ds,P,Q);


      SWRITE("\nSolution Formula:\n");
      FWPWRITE(SF);
      SWRITE("\n\nSolution Formula expressed with indices:\n");
      FWPIWRITE(SF);
      SWRITE("\n\n");
      NSFCONSTEI_STATS();
      SWRITE("\nStatistics for the CAD used for this construction:\n");
      PCADSTATS(Ds,Ps);

Return:/* Prepare to return. */      
      return;
}
