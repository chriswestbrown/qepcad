/**************************************************

This file "defines" the PCAD structure.

**************************************************/
#define SC_REP 1 
#define SC_PAR 2 
#define SC_INX 3 
#define SC_CDTV 4

