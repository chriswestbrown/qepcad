/*======================================================================
                     L <- LPFOWCS(C,P)

List of projection factors of which cell is a section.

Inputs
  C : A qepcad cell data structure.
  P : The qepcad data structure for the projection factors.

Outputs
  L : A list of projection factors whose level is the same as C, and
      which are identically zero in C.  These projection factors are
      ordered in the list by decreasing index.


THIS NEEDS FIXIN'!!!!  Should choose just one "level" from P.


======================================================================*/
#include "qepcad.h"

Word LPFOWCS(Word C, Word P)
{
      Word M,Pp,L,i;

      M = LELTI(C,MULSUB);
      Pp = P;
      for(L = NIL; Pp != NIL && M != NIL; M = RED(M)) {
	i = FIRST(FIRST(M));
	while( Pp != NIL && i > FIRST(RED(LELTI(FIRST(Pp),PO_LABEL))))
	  Pp = RED(Pp);
	if (Pp != NIL && i == FIRST(RED(LELTI(FIRST(Pp),PO_LABEL))))
	  L = COMP(FIRST(Pp),L); }
      L = CINV(L);

Return: /* Prepare to return. */
      return (L);

}
