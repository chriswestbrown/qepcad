#ifndef _LITTLE_ENDIAN_
#define _LITTLE_ENDIAN_
#endif
#undef _BIG_ENDIAN_
#define _X86_LINUX_
#define __WORDSIZE 64

