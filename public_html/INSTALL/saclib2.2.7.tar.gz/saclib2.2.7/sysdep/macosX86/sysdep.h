#ifndef _LITTLE_ENDIAN_
#define _LITTLE_ENDIAN_
#endif
#undef _BIG_ENDIAN_
#define _MAC_OSX_
#define __WORDSIZE 32

