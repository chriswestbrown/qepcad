#ifndef _BIG_ENDIAN_
#define _BIG_ENDIAN_
#endif
#undef _LITTLE_ENDIAN_
#define _SPARC_SOLARIS_
#define __WORDSIZE 32

#include <ucontext.h>

