/*======================================================================
                      PRFINISH()

Process "finish" command.
======================================================================*/
#include "saclib.h"
#include "qepcad.h"

void PRFINISH()
{

Step1: /* Process. */
       PCFINISH = 'y';
       PCUSEDES = 'n';

Return: /* Prepare for return. */
       return;
}
