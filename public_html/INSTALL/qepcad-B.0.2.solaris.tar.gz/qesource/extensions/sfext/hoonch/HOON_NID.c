/*  Hoon's method, no input dependence. */
#include "saclib.h"
#include "qepcad.h"

void HOON_NID()
{
      Word D,F,P,f,cs,t,F_e,F_n,F_s;

Step1: /* Initialize. */
      D = GVPC; F = GVNQFF; P = GVPF; f = GVNFV;

Step2: /* Construct dolution formula. */
      cs = ACLOCK();
      SOLUTION_MOD(D,F,P,f,&t,&F_e,&F_n,&F_s);
      cs = ACLOCK() - cs;

Step3: /* Output. */
      SWRITE("\nSOLUTION took "); IWRITE(cs); SWRITE(" miliseconds.\n");
      OUTPUTWR(t,F_e,F_n,F_s,GVVL);
      SWRITE("\n\n");

Return: /* */
      return;
}
