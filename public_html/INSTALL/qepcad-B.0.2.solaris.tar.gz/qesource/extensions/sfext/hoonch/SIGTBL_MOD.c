/*======================================================================
                      SIGTBL(c,f,T_t,T_f; Tp_t,Tp_f)

Signature Tables modified by chris.
It's modified to include cells in the truth table without regard to
how they got their truth values.

\Input
  \parm{c}  is a cell of the final partial CAD.
  \parm{f}  is the number of the free variables.
  \parm{Tt} is the list of signatures for propagation solution cells
            visited so far.
  \parm{Tf} is the list of signatures for propagation non-solution cells
            visited so far.

\Ouput
  \parm{T't} is the list of signatures obtained from $T_t$ by appending
             the signatures of the propagation solution cells over $c$.
  \parm{T'f} is the list of signatures obtained from $T_f$ by appending
             the signatures of the propagation non solution cells over $c$.
======================================================================*/
#include "saclib.h"
#include "qepcad.h"

void SIGTBL_MOD(c,f,T_t,T_f, Tp_t_,Tp_f_)
       Word c,f,T_t,T_f, *Tp_t_,*Tp_f_;
{
       Word S,S1,Sp,Tp_f,Tp_t,cb,cp,k;

Step1: /* At the $f$-space. */
       Tp_t = T_t; Tp_f = T_f;
       k = LELTI(c,LEVEL);
       if (k < f) goto Step2;
       if (LELTI(c,TRUTH) == TRUE || LELTI(c,TRUTH) == FALSE)
         {
         Sp = LELTI(c,SIGNPF);
         S  = NIL;
         while (Sp != NIL)
           {
           ADV(Sp,&S1,&Sp);
           S = CCONC(S1,S);
	   }
         if (LELTI(c,TRUTH) == TRUE)
           Tp_t = COMP(S,T_t);
         else
           Tp_f = COMP(S,T_f);
         }
       goto Return;

Step2: /* Other cases. */
       cb = LELTI(c,CHILD);
       if ( cb == NIL ) SWRITE("SIGTBL_MOD Error!\n");
       while (cb != NIL)
         {
         ADV(cb,&cp,&cb);
         SIGTBL_MOD(cp,f,Tp_t,Tp_f,&Tp_t,&Tp_f);
         }
       goto Return;

Return: /* Prepare for return. */
       *Tp_t_ = Tp_t;
       *Tp_f_ = Tp_f;
       return;
}
