/*======================================================================
Solution Formula Construction Full Dimensional cells only

Inputs:
D : a qepcad CAD structure
P : the projection factor set for D
J : the projection polynomial set for D, or possibly a superset
n : the level of the CAD (note that this can be less than the true level)

Side Effects:
A solution formula is written to standard out.

======================================================================*/
#include "saclib.h"
#include "qepcad.h"
#include "coarsecad.h"

void SFCFULLD(D,P,J,n)
      Word D,P,J,n;
{
      Word t,SF,Dp,Pp,Lt,Lf,LA,Q,D1,P1,D0,P0,J0,i,Lp,pflag, L;
      char e,s,m,c;

Step1: /* Space is either empty or R^n. */
      t = DOPFSUFF(P,LIST1(D));
      if (t == TRUE) {       
        SF = LIST1(TRUE);  /* CAD is identically TRUE. */
	SWRITE("\nTRUE\n");
        goto Return; }
      else if (t == FALSE) {
        SF = LIST1(FALSE); /* CAD is identically FALSE. */
	SWRITE("\nFALSE\n");
        goto Return; }

Step2: /* Extended language. */

      Dp = SCADDSCON(D,NIL,n);
      Pp = P;
      Dp = PCAD2ESPCAD(P,Pp,Dp,NIL);

      /* Initialization. */
      LTFOCALWTV(Dp,n,&Lt,&Lf);

      /* Only interested in full-dimensional cells */
      for(L = NIL; Lt != NIL; Lt = RED(Lt))
	if (n == CELLDIM(LELTI(FIRST(Lt),SC_REP)))
	  L = COMP(FIRST(Lt),L);
      Lt = L;
      for(L = NIL; Lf != NIL; Lf = RED(Lf))
	if (n == CELLDIM(LELTI(FIRST(Lf),SC_REP)))
	  L = COMP(FIRST(Lf),L);
      Lf = L;
	

      if (Lt == NIL && Lf == NIL) {
	SWRITE("No cells have truth values!\n");
	goto Return; }
      Lt = SPCADCBDD(Lt); /* sort true cells by decreasing dimension. */
      LA = LISTOETA(Pp,n);
      
      SF = NECCONDS(Lt,Lf,LA,Pp); 

      SF = FMASORT(SF);
      SF = FMA_REMCONST(SF);
      SF = FMASMOOTH(SF);
      SF = FMAOPCOMBINE(SF);
	  
      FMAWRITEQEIN(SF,Pp,GVVL);
      SWRITE("\n\n");
      
      
 Return: /* Prepare to return. */
      return;
}

