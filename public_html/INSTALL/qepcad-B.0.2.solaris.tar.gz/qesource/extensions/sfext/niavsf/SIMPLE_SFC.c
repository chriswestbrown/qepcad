#include "saclib.h"
#include "qepcad.h"

void SIMPLE_SFC()
{
      Word t,tp,tpp,Ps,Ds,Q,SF,C,i,D,P;

D = GVPC; P = GVPF; 
/* TIME */ t = ACLOCK();

Step0: /* Check for the trivial cases. */
      switch( DOPFSUFF(P,LIST1(D)) ) {
      case (TRUE) : SWRITE("\n\nInput is identically TRUE.\n\n");
	            goto Return;
      case (FALSE): SWRITE("\n\nInput is identically FALSE.\n\n");
	            goto Return; 
      case (NIL)  : SWRITE("\n\nThe projection set does not suffice.\n\n");
	            goto Return; }

Step1: /* Construct a minimal truth invariant CAD. */
      tpp = ACLOCK();
      CCADCONEXT(GVNFV,P,D,&Ps,&Ds,&Q);
      tpp = ACLOCK() - tpp;

StepX: /* Time for some more statistics! */
      tp = ACLOCK();
      SWRITE("\nStats for the minimal truth invariant CAD:\n");
      SWRITE("The truth invariant CAD was constructed in: ");
      IWRITE(tpp); SWRITE(" miliseconds\n");
      PCADSTATS(Ds,Ps);
      PPROJFWRITE(Ps);
      SWRITE("\nBack to your regularly scheduled program.\n");
      tp = ACLOCK() - tp;
      t += tp;

Step2: /* Find a minimal set of polynomials which suffice for SF const,
	  making use of the set Q computed in Step 1. */
      Ps = MINPFSET(P,Ps,D);

Step3: /* Construct a CAD from the proj-closure of Qs from step2. */
      CCADCONFPFS(GVNFV,P,D,Ps,&Ps,&Ds);

/* TIME */ t = ACLOCK() - t;

/* STAT */ SWRITE("\nSolution formula construction preprocessing time: ");
           IWRITE(t); SWRITE("\n");

Step4: /* Construct that solution formula. */
      SF = NSFCONST(Ds,P,Ps);


      SWRITE("\nSolution Formula:\n");
      FWPWRITE(SF);
      SWRITE("\n\nSolution Formula expressed with indices:\n");
      FWPIWRITE(SF);
      SWRITE("\n\n");
      NSFCONST_STATS();
      SWRITE("\nStatistics for the CAD used for this construction:\n");
      PCADSTATS(Ds,Ps);

Return:/* Prepare to return. */      
      return;
}
