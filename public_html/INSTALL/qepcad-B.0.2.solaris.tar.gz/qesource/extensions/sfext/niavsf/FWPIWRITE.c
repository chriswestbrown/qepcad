/*======================================================================
                 FWPIWRITE(F)

Formula with polynomial indices write.

Inputs
 F : A formula.
Side Effects
 F is written to standard out, using the polynomial lables.

======================================================================*/
#include "saclib.h"
#include "qepcad.h"

void FWPIWRITE(F)
      Word F;
{
      Word O,Fp,A,t;

Step1: /* F is an atomic formula. */
      if (FTYPEINFO(F) == NIL) {
	SWRITE("P_");
	OWRITE(RED(LELTI(FIRST(F),PO_LABEL)));
	switch(SECOND(F)) {
	case (LTOP) : SWRITE(" < 0"); break;
	case (LEOP) : SWRITE(" <= 0"); break;
	case (GTOP) : SWRITE(" > 0"); break;
	case (GEOP) : SWRITE(" >= 0"); break;
	case (EQOP) : SWRITE(" = 0"); break;
	case (NEOP) : SWRITE(" /= 0"); break; }
	goto Return; }

Step2: /* F is a disjunction or conjunction. */
      ADV(F,&O,&Fp);
      do {
        ADV(Fp,&A,&Fp);
        t = FTYPEINFO(A);
        if (t != NIL && t != O) { SWRITE("[ "); FWPIWRITE(A); SWRITE(" ]"); }
        else FWPIWRITE(A);
      if (Fp == NIL) break;
        if (O == OROP)  SWRITE(" \\/ ");
        if (O == ANDOP) SWRITE(" /\\ ");
      } while(1);

Return: /* Prepare to return. */
      return;
}
