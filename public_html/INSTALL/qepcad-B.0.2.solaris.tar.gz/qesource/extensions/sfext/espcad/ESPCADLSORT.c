/*
ESPCAD-cell list sort.

L : a list of ESPCAD cells.

P : the projection factor structure to which the cell's
    signitures refer.

This will sort a list of cells based purely their signitures,
i.e. indexed roots will not be considered.
 */

static comp(Word c1, Word c2)
Word ESPCADLSORT(L,P)
       Word L,P;
{


}
