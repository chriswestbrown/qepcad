/*======================================================================
                 ModLTFOCWTV(C;Lt,Lf)

List (true/false) of cells with truth values this lists them in an
order with decreasing dimension.

Inputs
  C : A pruned partial cad.

Outputs
  Lt : A list of all true cells.
  Lf : A list of all false cells.
======================================================================*/
#include "saclib.h"
#include "qepcad.h"
#include "coarsecad.h"

Word ModLTFOCWTV(C,Lt_,Lf_)
      Word C,*Lt_,*Lf_;
{
      Word L,Cp,Lt,Lf,t,Ltp,Lfp;
      Word Q1,Q0,J;

Step1: /* If C is undetermined recurse on the children. */
      t = LELTI(C,SC_CDTV); 
      switch (t) {
      case (TRUE) :
        Lt = LIST1(C); Lf = NIL; break;
      case (FALSE) :
        Lf = LIST1(C); Lt = NIL; break;
      default :
        Lf = NIL; Lt = NIL;
        if (!ISLIST(t)) break;

Q0 = NIL;
Q1 = LIST1(FIRST(t));
 for(J = RED(t); J != NIL; J = RED2(J)) {
   Q0 = COMP(FIRST(J),Q0);
   Q1 = COMP(SECOND(J),Q1); }

        for(Cp = CONC(Q0,Q1); Cp != NIL; Cp = RED(Cp)) {
          LTFOCWTV(FIRST(Cp),&Ltp,&Lfp);
          Lt = CONC(Ltp,Lt);
          Lf = CONC(Lfp,Lf); }
        break; }

Return:
      *Lt_ = Lt;
      *Lf_ = Lf;
      return;
}
