/*
                     t <- FMADMQ(F,C,k)

ForMulA defines marks query.

F : a formula
C : a cell
k : a level --- any cell k-levels above C is taken to be a leaf,
    even if it actually has children.

t : 1 if F does define the marks for the CAD of C x R^k, 0 otherwise.

*/

#include "extlang.h"

Word FMADMQ(F,C,k)
       Word F,C,k;
{
  Word t,L;

  if (k == 0 || !ISLIST(LELTI(C,SC_CDTV)))
    t = (FMACELLEVAL(F,C) == LELTI(C,SC_CDTV));
  else {
    L = LELTI(C,SC_CDTV);
    for(t = 1; t && L != NIL; L = RED(L))
      t = FMADMQ(F,FIRST(L),k-1); }
  return t;

}
