/* Header file for 2D adjacency code. */
#include "saclib.h"
#include "qepcad.h"

/* AD2D_Cell definitions. */
#define AD2D_Index 1
#define AD2D_Mult  2

/* Package definitions. */
#define AD2D_FAIL 0
#define AD2D_Infy BETA - 1
#define AD2D_N_In -1
#define AD2D_ErrI -2

/* C Function Prototypes */
Word ADJ_2D(Word c,Word c_l,Word c_r,Word P,Word J);
Word ADJ_2D_PART(Word c,Word c_l,Word c_r,Word P,Word J);
Word ADJ_2D1_COMPLETE(Word c,Word c_l,Word c_r,Word P,Word J);

Word AD2DC_CONS(Word c,Word P);
Word AD2DS_CONS(Word c,Word P);
Word ADD_2_SOL(Word a,Word S);

Word DISCMASK(Word c,Word P,Word J);
Word LDCOEFMASK(Word c,Word P,Word J);
Word Mystery_f(Word L,Word R,Word M);

Word VECTOR_LTEQ(Word u,Word v);
Word VECTOR_SUM(Word u,Word v);
Word SUM_NORM_SP(Word v);
Word CWD_VECTOR_Q(Word u,Word v);
Word ZERO_VECTOR(Word n);
Word VECTOR_S_PROD(Word s,Word v);
Word VECTOR_SEMI_COMP(Word u,Word v);
Word EQUAL_ON_ONES(Word u,Word v);

Word P1(Word U,Word V,Word W,Word v_l,Word B);
Word P2(Word x_l,Word x_r,Word U,Word V,Word W,Word v_l,Word B);
Word P3(Word U,Word V,Word W,Word v_l,Word B);
Word P4(Word U,Word V,Word W,Word v_l,Word B);

void DIMENSIONS(Word D,Word *d1_,Word *d2_);
Word GET_COLOR(Word D,Word p1,Word p2);
void GET_COORD_EST(Word D,Word I,Word xF,Word yF,Word d2,Word *x_,Word *y_);
