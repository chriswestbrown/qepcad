#include "saclib.h"
#include "qepcad.h"
#include <iostream.h>

int get_coords(Word *x, Word *X, Word *y, Word *Y, Word *e, Word *d1, Word *d2)
{
  if (!(cin >> *x >> *X >> *y >> *Y))
    return 0;

  *e = LBRNREAD();
  if (e == 0)
    return 0;
  
  if (! (cin >> *d1 >> *d2) )
    return 0;
  
  return 1;
}
