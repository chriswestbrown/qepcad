/*======================================================================
                      PRDADJINFO()

Process "display the adjacency info" command.
======================================================================*/
#include "saclib.h"
#include "qepcad.h"

void PRDADJINFO()
{

Step1: /* Do it. */
       ADJINFOWR();

Return: /* Prepare for return. */
       return;
}
