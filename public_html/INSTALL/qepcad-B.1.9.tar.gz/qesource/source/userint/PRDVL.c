/*======================================================================
                      PRDVL()

Process "display variable list" command.
======================================================================*/
#include "saclib.h"
#include "qepcad.h"

void PRDVL()
{

Step1: /* Process. */
       VLWRITE(GVVL); SWRITE("\n");

Return: /* Prepare for return. */
       return;
}
