/*===========================================================================
                         t <- VALIDLBL(L)

Valid label?

Inputs
  L : a triple (C,i,j), where C is a list of characters and i and j are 
      BETA-digits.

Output
  t : If L is the label of some polynomial in GVPF then t = TRUE,
      otherwise t = FALSE.
===========================================================================*/
#include "saclib.h"
#include "qepcad.h"

Word VALIDLBL(L)
       Word L;
{
       Word t,P,P1,A;

Step1: /* Initialize. */
       P = GVPF;
       t = FALSE;

Step2: /* Loop. */
       while (P != NIL) {
	 ADV(P,&P1,&P);
	 while (P1 != NIL) {
	   ADV(P1,&A,&P1);
	   if (EQUAL(LELTI(A,PO_LABEL),L)) {
	     t = TRUE;
	     goto Return; } } }

Return: /* Prepare for return. */
       return(t);
}
