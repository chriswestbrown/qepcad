/*======================================================================
                      PROMPT()

Write the prompt.
======================================================================*/
#include "saclib.h"
#include "qepcad.h"

void PROMPT()
{
Step1: /* Write the prompt. */
       /* SWRITE("\nQEPCAD: "); */

Return: /* Prepare for return. */
       return;
}
