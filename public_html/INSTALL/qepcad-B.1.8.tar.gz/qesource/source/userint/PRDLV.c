/*======================================================================
                      PRDLV()

Process  "display the current level" command.
======================================================================*/
#include "saclib.h"
#include "qepcad.h"

void PRDLV()
{

Step1: /* Process. */
       GWRITE(GVLV); SWRITE("\n"); goto Return;

Return: /* Prepare for return. */
       return;
}
