#include "saclib.h"
#include "qepcad.h"

/* Added to get this to compile! */
Word PRIME;
Word NPRIME;
Word SMPRM;
Word NSMPRM;
/* End Added. */
/*====================================================================
                 main(argc,argv)

Main Algorithm which drives the QEPCAD sytem. 
====================================================================*/
int main(argc, argv)
       int argc;
       char **argv;
{
       Word Fs,F_e,F_n,F_s,V,t,ac;
       char **av;

Step1: /* Set up the system. */
       ARGSACLIB(argc,argv,&ac,&av);
       BEGINSACLIB((Word *)&argc);
       replace_saclib(0);
       QEGLOBALS();
       SETUPSYS();

/* Added to get output to be line buffered.  Chris. */
setlinebuf(stdout);
/* End added. */

Step2: /* Read in an input. */
       INPUTRD(&Fs,&V);
                /*Int*/ GVVL = V;
                /*Int*/ GVF = Fs;
                /*Int*/ FIRST4(Fs,&GVNV,&GVNFV,&GVQ,&GVQFF);

Step3: /* Initialize the qepcad system globals. */
       INITSYS();


/* Added to get this to compile! */
PRIME = LPRIME;
NPRIME = NLPRIME;
SMPRM = SPRIME;
NSMPRM = NSPRIME;
/* End Added. */


Step4: /* Call QEPCAD. */
                /*Int*/ BTMQEPCAD = ACLOCK();
CAD2D(Fs,&t,&F_e,&F_n,&F_s);

Step5: /* Write out the output. */
       OUTPUTWR(t,F_e,F_n,F_s,V);
                /*Int*/ if (TCSTAT == 'y') STATWR();
               /*Int*/ if (TCDSTAT == 'y') DSTATWR();

Step6: /* Clean up the system. */
       CLEANUPSYS();
       STATSACLIB();
       ENDSACLIB(SAC_FREEMEM);

Return: /* Prepare for return. */
       return (0);
}

