/*======================================================================
                      s <- SSBRICRI(a,b)

Smallest standard binary rational interval containing rational interval.

Inputs
      a : A rational number.
      b : A rational number, b > a, and sign(a) != -1 * sign(b).
Outputs
      s : A standard interval with binary rational endpoints containing
          the interval (a,b).

======================================================================*/
#include "saclib.h"


Word SSILRICRIEZ(a_,b_)
       Word a_,b_;
{
       Word s,a,b,d,f,p,x,n,t1,t2;

Step0: /* Reflect interval if neccesary. */
       if (RNSIGN(a_) == -1) {
	 s = 1;
	 a = RNNEG(b_);
	 b = RNNEG(a_); }
       else {
	 s = 0;
	 a = a_;
	 b = b_; }

Step1: /* Set p to the smallest natural number s.t. 2^p >= a - b.  */
       d = RNDIF(b,a);
       RNFCL2(d,&f,&p); /* p = ceiling( log_2(d) ). */

Step2: /* Test if a standard interval of width 2^p exists containing 
	  (a,b). If not, increment p and try again. */
       x = RNP2(p);
       n = RNFLOR(RNQ(a,x));
       t1 = ISUM(n,1);
       if (p >= 0)
         t2 = RNINT(IMP2(t1,p));
       else
	 t2 = RNPROD(RNINT(t1),x);
       if (RNCOMP(t2,b) >= 1)
	 goto Return;
       else {
	 p++;
	 goto Step2; }

Return: /* Return, reflecting the output interval if needed. */
       if (s)
	 return (LIST2(RNLBRN(t2),RNLBRN(RNNEG(RNPROD(RNINT(n),x)))));
       else
	 return (LIST2(RNLBRN(RNPROD(RNINT(n),x)),RNLBRN(t2)));
}
