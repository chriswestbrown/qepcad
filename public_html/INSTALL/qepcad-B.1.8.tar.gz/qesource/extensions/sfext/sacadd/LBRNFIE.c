/*======================================================================
                      Ib <- LBRNFIE(I,e)

Logarithmic binary rational number from integer and exponent.

Inputs
      I : An integer.
      e : A BETA-digit.
Outputs
      R: Logarithmic binary rational representation of I*2^e.

======================================================================*/
#include "saclib.h"

Word LBRNFIE(I,e)
       Word I,e;
{
       Word J,g,n;

Return: /* Prepare to return. */
       return LBRNP2PROD( ILBRN(I) , e );
}
