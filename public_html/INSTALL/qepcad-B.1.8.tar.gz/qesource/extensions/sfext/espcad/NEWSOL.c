/*
New Solution Formula.  Uses a simple CAD (with some projection
factors added back if necessary to ensure projection definability.
 */


#include "espcad.h"

extern void STRAIGHTFORWARDSF(Word,Word,Word,Word);

void NEWSOL(Word D, Word P, Word n)
{
      Word Dp,Lt,Lf,L,Lp,Pp,t,Q;

Step1: /* Space is either empty or R^n. */
      t = DOPFSUFF(P,LIST1(D));
      if (t == TRUE)
	SWRITE("\n\nInput is identically TRUE.\n\n");
      else if (t == FALSE)
	SWRITE("\n\nInput is identically FALSE.\n\n");
      else if (t == NIL) {
	SWRITE("\n\nThis CAD is not projection definable.\n\n");
	CCADCON(n,P,D,&Pp,&Dp);
	Dp = PCAD2ESPCAD(P,Pp,Dp,NIL);
	LTFOCWTV(Dp,&Lt,&Lf);
	t = ACLOCK();
	Lt = SPCADCBDD(Lt);
	Q = NAIVESF(Lt,Lf,LISTOETA(Pp,n),Pp);
	t = ACLOCK() - t;
	SWRITE("\nNew NAIVESF took: "); IWRITE(t); SWRITE(" ms.\n");
	FMAWRITE(Q,Pp,GVVL);
	SWRITE("\n\n");	
	FMAWRITEp(Q,Pp,GVVL,0);
	SWRITE("\n\n");	
	t = ACLOCK();
	Lt = SPCADCBDD(Lt);
	Q = NECCONDS(Lt,Lf,LISTOETA(Pp,n),Pp);
	t = ACLOCK() - t;
	SWRITE("\nNew NECCONDS took: "); IWRITE(t); SWRITE(" ms.\n");
	FMAWRITE(Q,Pp,GVVL);
	SWRITE("\n\n");	
	FMAWRITEp(Q,Pp,GVVL,0);
	SWRITE("\n\n");	
      }
      else {

Step2: /* Construct a simple ESPCAD for D, and 
	  check projection definability. */
	CCADCON(n,P,D,&Pp,&Dp);
	Dp = PCAD2ESPCAD(P,Pp,Dp,NIL);
	t = ESPCADDOPFSUFF(Pp,LIST1(Dp));

Step3: /* Put back some projection factors if needed. */
	if (t == NIL) {
	  Q = MINPFSET(P,Pp,D);
	  CCADCONFPFS(n,P,D,Q,&Pp,&Dp);
	  Dp = PCAD2ESPCAD(P,Pp,Dp,NIL); }

Step4: /* Construct formula. */
	LTFOCWTV(Dp,&Lt,&Lf);
	STRAIGHTFORWARDSF(Lt,Lf,Pp,n);
	SWRITE("\nJANUARYSF\n\n"); JANUARYSF(Lt,Lf,Pp,n);

      /**********************************************
       ** NEW STUFF!
       **********************************************/
	t = ACLOCK();
	Lt = SPCADCBDD(Lt);
	Q = NECCONDS(Lt,Lf,LISTOTA(Pp,n),Pp);
	t = ACLOCK() - t;
	SWRITE("\nNew NECCONDS took: "); IWRITE(t); SWRITE(" ms.\n");
	FMAWRITE(Q,Pp,GVVL);
	SWRITE("\n\n");


	t = ACLOCK();
	Lt = SPCADCBDD(Lt);
	Q = NAIVESF(Lt,Lf,LISTOTA(Pp,n),Pp);
	t = ACLOCK() - t;
	SWRITE("\nNew NAIVESF took: "); IWRITE(t); SWRITE(" ms.\n");
	FMAWRITE(Q,Pp,GVVL);
	SWRITE("\n\n");	

      }

Return: /* Prepare to return. */
      /**********************************************
       ** NEW STUFF!
       **********************************************/
        SWRITE("CYLFORM: ");
	t = ACLOCK();
	Q = CYLFORM(Dp,Pp,n,LISTOETA(Pp,n));
	t = ACLOCK() - t;
	SWRITE(" took "); IWRITE(t); SWRITE(" ms.\n");
	FMAWRITE(Q,Pp,GVVL);
	SWRITE("\n\n");	

        SWRITE("CYLIMPFORM: ");
	t = ACLOCK();
	Q = CYLIMPFORM(Dp,Pp,n,LISTOETA(Pp,n));
	t = ACLOCK() - t;
	SWRITE(" took "); IWRITE(t); SWRITE(" ms.\n");
	FMAWRITE(Q,Pp,GVVL);
	SWRITE("\n\n");	

        SWRITE("Geotest:");
	t = ACLOCK();
	Q = GEOTEST(Dp,Pp,n,LISTOETA(Pp,n));
	t = ACLOCK() - t;
	SWRITE(" took "); IWRITE(t); SWRITE(" ms.\n");
	FMAWRITE(Q,Pp,GVVL);
	SWRITE("\n\n");	
      return;
}
