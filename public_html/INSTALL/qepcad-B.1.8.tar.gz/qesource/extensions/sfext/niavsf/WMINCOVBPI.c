/*======================================================================
                 MINCOVBPI(T,L,P)

Weighted minimum cover by prime implicants.

Inputs
 T :  A list of pruned CAD cells.
 L :  A list of prime implicants which covers the cells in T.
 P :  The projection factor data structure to which the signitures of
      the cells in T refer.

Outputs
 C :  A minimum weight subset of L which also covers T.

======================================================================*/
#include "saclib.h"
#include "qepcad.h"


Word WMINCOVBPI(T,L,P)
      Word T,L,P;
{
      Word Q,t,K,i,Cp,C,Lp;

Step1: /* Construct Hit Set Problem. */
      for(Q = NIL; T != NIL; T = RED(T)) {
	t = FIRST(T); K = NIL;i = 1;
	for(Lp = L; Lp != NIL; Lp = RED(Lp)) {
	  if (EFIC(FIRST(Lp),t,P) == TRUE)
	    K = COMP(LIST2(i,LENGTH(FIRST(Lp))),K);
	  i++; }
	Q = COMP(INV(K),Q); }

Step2: /* Find minimum hitting set and translate back to implicants. */
      Cp = MINWEIGHTHITSET(Q,-1);
      for(C = NIL; Cp != NIL; Cp = RED(Cp)) {
	C = COMP(LELTI(L,FIRST(FIRST(Cp))),C); }
 
Return: /* Return. */
	return (C);

}
