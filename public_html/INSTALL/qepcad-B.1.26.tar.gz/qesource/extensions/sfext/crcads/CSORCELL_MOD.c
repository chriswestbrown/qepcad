/*======================================================================
                     CSORCELLTR_MOD(c,Pp,PpO,PpN,P)

Construct stack over RCell: total rebuild - Modified to work right
with equational constraints.

Inputs
  c  : An RCell which is not of the highest level.
  Pp : will be the level k+1 projection factors, given as PpO, PpN.
  PpO: will be the original k+1 projection factors.
  PpN: PpN will be the new k+1 level projection factors.
  P  : The projection factor set defining the CAD in which c
       resides, or the projection factor set defining the CAD
       in which LELTI(c,RNCELL) resides.

Side Effects
  A stack is constructed over c.  The information from INCELL is only
  used for truth value assignments, not to help build the stack.
  
======================================================================*/
#include "qepcad.h"
#include "newpols.h"
static Word ISCSOPP(Word c,Word M);
static Word LLPFZC(Word c,Word P);

void QepcadCls::CSORCELLTR_MOD(Word c, Word Pp, Word PpO, Word PpN, Word P)
{
      Word f,s,sh,M,K,C,Pps,L,T,B,E,I,A,a,b,k;
      Word PP,NP,L_P,TP,i,ta,t;

Step0:
      k = LELTI(c,LEVEL);
      s = LELTI(c,SAMPLE);
      sh = CONVERT(s,k);
      SLELTI(c,SAMPLE,sh);
      CONSTRUCTmod(c,k,GVNFV,Pp);

Step5: /* Add two new fields to each cell to make it an RCell. */
      T = NIL;
      for(A = LELTI(c,CHILD); A != NIL; A = RED(A)) {
	T = COMP(CCONC(FIRST(A),LIST2(NIL,NIL)),T); }
      SLELTI(c,CHILD,CINV(T));
      
Step6: /* Add truth values and other information. */
       
       /* Get mask for pivot pol's, i.e. a list of
	  1's and zeros corresponding to PpO, where
	  the non-pivot pol positions are 1, and
	  the pivot pol positions are zero. */

      SEPPIVNONPIV(LELTI(P,k+1),k+1,&PP,&NP); /* Get list of pivot pol's for this level. */
      if ( (NP != NIL) && SINTER(LELTI(GVPIVOT,k+1),LLPFZC(c,P)) != NIL ) {
	PP = LELTI(P,k+1); NP = NIL; }

      L_P = NIL;
      ta = FIRST(LELTI(FIRST(LELTI(c,CHILD)),SIGNPF)); /* signiture of a sector on level 
							  k+1 pols. */
      for(TP = LELTI(P,k+1); TP != NIL; TP = RED(TP)) {
	  /* Subtle point:  a pivot pol might vanish identically in this stack,
	     which would mess everything up.  If this pol does vanish identically
	     in the stack, don't include it in the mask! */
	ADV(ta,&i,&ta); /* sign of current pol in a sector: if 0 then pol vanishes in stack. */
	if ( PFPIPFL(FIRST(TP),PP) &&  i ) {
	  L_P = COMP(0,L_P); }
	else
	  L_P = COMP(1,L_P); }
      L_P = INV(L_P);

      A = LELTI(c,CHILD);               /* Stack with more cells, i.e. new.  */
      B = LELTI(LELTI(c,INCELL),CHILD); /* Stack with fewer cells, i.e. old. */
      ADV(B,&b,&B);
      ADV(A,&a,&A);

      while (A != NIL) {

	SLELTI(a,INCELL,b); 
	SLELTI(a,TRUTH,LELTI(b,TRUTH)); 
	SLELTI(a,HOWTV,LELTI(b,HOWTV));
	ADV(A,&a,&A);
	if (LELTI(b,MULSUB) != NIL)
	  ADV(B,&b,&B); /* i.e. if b is a section. */
	if ( ISCSOPP(a,L_P) ) {
	  do{
	    ADV(B,&b,&B);
	  } while( ! ISCSOPP(b,L_P) ); } }
	  

      SLELTI(a,INCELL,b);
      SLELTI(a,TRUTH,LELTI(b,TRUTH));
      SLELTI(a,HOWTV,LELTI(b,HOWTV));

Return: /* */
      return;
}

/*======================================================================
Is cell a section of a pivot pol?

c : a cell.
M : the mask.
======================================================================*/

static Word ISCSOPP(Word c,Word M)
{
      Word S,L,s,l,t;

Step1: /* Check the first zero entry of a's signiture on b. */
      S = FIRST(LELTI(c,SIGNPF));
      L = M;
      t = 0;
      while( L != NIL ) {
	ADV(L,&l,&L);
	ADV(S,&s,&S);
	if ( s == 0 && l == 0 ) {
	  t = 1; break; } }

      return (t);
}



/*======================================================================
List of all labels of all proj fac's which are zero in cell.
======================================================================*/

static Word LLPFZC(Word c,Word P)
{
      Word S,N,L,S_i,P_i,i,s,p;

      S = LELTI(c,SIGNPF);
      N = LENGTH(S);
      L = NIL;
      for(i = N; i > 0; i--) {
	S_i = LELTI(S,N - i + 1);
	P_i = LELTI(P,i);
	while( P_i != NIL ) {
	  ADV(S_i,&s,&S_i);
	  ADV(P_i,&p,&P_i);
	  if (s == 0)
	    L = COMP(p,L); } }
       
      return (L);

}

/*======================================================================
                      CONSTRUCTmod(c,k,f,Ps,As)

Construct a stack.
 
\Input
    \parm{c}  is a candidate cell of~\v{D}.
    \parm{k}  is the level of the cell~\v{c}.
    \parm{f}  is the number of free variables in the input formula.
    \parm{P*} is the list of the $(k+1)$--level projection factors.
 
\Output
    A stack is constructed over the cell~\v{c}.
======================================================================*/
void QepcadCls::CONSTRUCTmod(Word c,Word k,Word f,Word Ps)
{
        BDigit p,t,Ths;
        Word A1,As1,At,B,b,E,I,Ip,I1,J,Jp,L,M,P1,Ps1,Pt,Pt1,S,s,T,Q;
	Word junk,a1,b1,t1,p1,j1;

Step1: /* Extract the projection factors from their attribute lists. */

Step2: /* Root cell. */
       if (k > 0) goto Step3;
       SLELTI(c,DEGSUB,PLDEG(Ps));

       if (Ps != NIL) I = IPLRRI(Ps); else I = NIL;
 
       EC1(c,I,Ps);

       SIGNP1(c,Ps,I);
    
       goto Return;

Step3: /* Non-root cell, Irrational sample point. */
       s = LELTI(c,SAMPLE); FIRST3(s,&M,&J,&b);
       if (PDEG(M) == 1      
                             /*Int*/ && PCRSP == 'y'
          ) goto Step4;

    
           S = SUBSTDB(c,k,M,b,Ps,*this);
	                     /*Int*/ if (LSRCH('l',PCPROJOP) != 0 && LSRCH(0,S) != 0)
                             /*Int*/   FAIL("CONSTRUCT","Substitution failed",k,M,b,Ps,S);

       SLELTI(c,DEGSUB,PLDEG(S));
       AFUPLM(M,S,&L,&T);
        AFCSBMDB(M,T,&B,&E);
 
        if (B != NIL) {
           if (PCAFUPBRI == 1) {
              Jp = BRILBRI(J);
              AFUPHIBRI(M,Jp,B, &I,&t);
              if (t == 0) {
                 Ip = I;
                 while (Ip != NIL) {
                    I1 = FIRST(Ip);
                    I1 = LBRIBRI(I1);
                    SFIRST(Ip,I1);
                    Ip = RED2(Ip); } }
              if (t != 0) {
                 SWRITE("AFUPHIBRI failed, t = ");
                 OWRITE(t);
                 SWRITE("\n");
                 SWRITE("Cell index: ");
                 LWRITE(LELTI(c,6));
                 SWRITE("\n");
                 p = 2;
                 Jp = BRILBRI(J);
                 I = 0;
                 while (I == 0 && p <= 10) {
                    AFUPSIBRI(M,Jp,B,p, &Jp,&I);
                    SWRITE("p = ");
                    IWRITE(p);
                    SWRITE("\n");
                    p = p + 1; }
                 if (I == 0) {
                    I = AFUPBRI(M,J,B);
		 }}}
              else {
                 I = AFUPBRI(M,J,B);
	      } }
        else
	  I = NIL;
       EC(c,I,E,B);
       SIGNP(c,k,B,I,E,L);
       goto Return;

Step4: /* Non-root cell, Rational sample point. */
       b = RCFAFC(b);
       S = SUBSTR(c,k,b,Ps);
                             /*Int*/ if (LSRCH('l',PCPROJOP) != 0 && LSRCH(0,S) != 0)
                             /*Int*/   FAIL("CONSTRUCT","Substitution failed",k,M,b,Ps,S);
       SLELTI(c,DEGSUB,PLDEG(S));

       IPLSRP(S,&s,&T);

       IPFSBM(1,T,&B,&E);

       if (B != NIL) I = IPLRRI(B); else I = NIL;

       ECR(c,I,E,B);

       SIGNPR(c,k,B,I,E,s);

Return: /* Prepare for return. */
       return;
}




