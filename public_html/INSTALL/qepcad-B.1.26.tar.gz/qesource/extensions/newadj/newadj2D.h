#include "adj2D.h"

Word HA(Word c, Word c_l, Word P, Word J, Word D);
Word HAC_CONS(Word c, Word P);
Word HALDCOEFMASK(Word D, Word c, Word P, Word J);
Word HAP1(Word U, Word V, Word w_l, Word B);
Word HAP2(Word U, Word V, Word w_l, Word B);
Word HAP3(Word U, Word w_l, Word B);
Word HAS_CONS(Word c, Word P);
void HATEST(Word D, Word P, Word J);
