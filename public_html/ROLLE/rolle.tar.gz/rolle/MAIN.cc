/**************************************************************************
 * rolle:  This is a modified version of QEPCAD B.  It's designed to compute
 * "sign-stack sequences".  A sign-stack sequence is defined elsewere. 
 * INPUT: Let p be a monic degree n polynomial in Z[a1,..,ak][x].  Your
 *        input formula should look like 
 *        (G a1)(G a2)...(G ak)(C x)
 *        [ 
 *               p = 0 /\ p' = 0 /\ p^(2) = 0 /\ ... /\ p^(n-1) = 0 
 *        ].
 * OUTPUT:  This revised version of QEPCAD B will print out all the
 *          sign-stack sequences realized by p and its derivatives
 *          generically.  This means we ignore the sign-stack sequences
 *          for p when there is a common zero beteen some pair of p and
 *          its derivatives.
 *
 * Changes to Qepcad are:
 * 1) "main" is modified to print out sign-stack sequences at the end.
 * 2) PROPAGATE is modified so that the "C" quantifier is processed by
 *    a) recording the sign-stack sequence, and b) always returning TRUE.
 * 3) Some extra functions and classes are defined to track and process
 *    sign-stack sequences.
 *                                                 Chris Brown 6/28/04
 *                                             Compiles with QEPCAD B 1.28
 **************************************************************************/
#include "qepcad.h"
#include <vector>
#include <set>
#include <iostream>

/**********************************************************************
 ** Code for computing with sign stacks encoded as bits packed into an
 ** integer: 1='+' and 0='-'
 **********************************************************************/

// Provides the comparison function for sign-stack sequences encoded
// as vectors of ints.  Comparison is lexicographic
class SSComp
{ public:
  bool operator()(const vector<int> &a, const vector<int> &b) {
    for(int i = 0; i < min(a.size(),b.size()); ++i)
      if (a[i] < b[i]) return true;
      else if (b[i] < a[i]) return false; 
    return (a.size() < b.size());
  }
};

// File scope variable for storing the set of all sign-stack sequences
set< vector<int> , SSComp > SSS;

// Input:  S: a QEPCAD signature structure
// Output: m, an int, such that if the highest level projection
//         factors have signature +-+...+-, m is binary 101...10,
//         i.e. 1 for + and 0 for -
int ssconvert(Word S)
{
  Word L;
  int m = 0;
  for(L = FIRST(S); L != NIL; L = RED(L)) {
    m <<= 1;
    if (FIRST(L) == POSITIVE) m |= 1; }
  return m;
}

// Prints sign-stack encoded as vector<int> as +/-'s
ostream& ssprint(const vector<int> ss,ostream &out, QepcadCls &Q)
{
  int n = LENGTH(LELTI(Q.GVPF,Q.GVNV));
  for(int i = 0; i < ss.size(); ++i)
  {
    for(int b = 1 << (n-1); b > 0; b >>= 1)
      out << (ss[i]&b ? '+' : '-');
    out << ' ';
  }
  return out;
}  


/*====================================================================
                 main(argc,argv)

Main Algorithm which drives the QEPCAD sytem. 
====================================================================*/
int main(int argc, char **argv)
{
       Word Fs,F_e,F_n,F_s,V,t,ac;
       char **av;

Step1: /* Set up the system. */
       ARGSACLIB(argc,argv,&ac,&av);
       BEGINSACLIB((Word *)&argc);
       BEGINQEPCAD();

Step2: /* Read input, create CAD, write result */
       PRINTBANNER();
       INPUTRD(&Fs,&V);
       QepcadCls Q(V,Fs);
       BTMQEPCAD = ACLOCK();
       Q.QEPCAD(Fs,&t,&F_e,&F_n,&F_s);

       /********************************************************************
	* Print out sign-stack sequences!  This is the new stuff!
	********************************************************************/
       for(set<vector<int> >::iterator i = SSS.begin(); i != SSS.end(); ++i)
	 ssprint(*i,cout,Q) << endl;
       /********************************************************************/

Step3: /* Clean up the system. */
       SWRITE("\n=====================  The End  =======================\n");
       STATSACLIB();
       ENDQEPCAD();
       ENDSACLIB(SAC_FREEMEM);

Return: /* Prepare for return. */
       return 0;
}


/*======================================================================
                      PROPAGATE(D,c,k,f,Q)

Propagate truth values. (The "C" quantifier has been modified as discribed above!)

\Input
   \parm{D} is a partial CAD.
   \parm{c} is a cell in $D$.
   \parm{k} is the level of the cell~$c$.
   \parm{f} is the number of free variables in the input formula.
   \parm{Q} is the list $(Q_{f+1},\ldots,Q_r)$  of the quantifiers
            in the input formula.

\Output
   The truth values of the cell~$c$ and some of its ancestors 
   are determined if possible.
   The descendants of each cell whose truth value
   has been determined through the propagation are removed from the
   partial CAD~$D$.
======================================================================*/
void PROPAGATE(Word D, Word c, Word k, Word f, Word Q)
{
       Word A0,A1,E0,E1,cp,k0,kp,q,C0,L;
       /* hide A0,A1,E0,E1,kp; */

Step1: /* Initialize. */
       cp = c; kp = k; k0 = LELTI(D,LEVEL);

Step2: /* Done? */
       if (kp < f  || kp < k0) goto Return;

       /* "X" quantifier! Exactly k */
       q = LELTI(Q,kp + 1 - f);
       if (ISLIST(q) && FIRST(q) == EXISTk) {
	 C0 = TCHILD4EXk(cp,SECOND(q));
	 if (C0 == TRUE || C0 == FALSE)
         { SLELTI(cp,TRUTH,C0); SLELTI(cp,HOWTV,BYPRP); goto Step8;}
	 goto Return; }
       /* End "X" quantifier. */

       /* HEAVILY MODIFIED "C" quantifier!*/
       if (LELTI(Q,kp + 1 - f) == CONTQ) {
	 vector<int> SS;
	 L = LELTI(c,CHILD);
	 do {
	   SS.push_back(ssconvert(LELTI(FIRST(L),SIGNPF)));
	   L = RED(L);
	   if (L == NIL) break;
	   L = RED(L);
	 }while(1);
	 SSS.insert(SS);
	 SLELTI(cp,TRUTH,TRUE); SLELTI(cp,HOWTV,BYPRP); goto Step8;}
       /* End "C" quantifier. */

       /* "F" quantifier! Exists full dimensional (i.e. infinitely many) */
       if (LELTI(Q,kp + 1 - f) == FULLDE) {
	 C0 = TCHILD4FDE(cp);
	 if (C0 == TRUE || C0 == FALSE)
	   { SLELTI(cp,TRUTH,C0); SLELTI(cp,HOWTV,BYPRP); goto Step8;}
	 goto Return; }
       /* End "F" quantifier. */

       /* "G" quantifier! Full dimensional "for all" */
       if (LELTI(Q,kp + 1 - f) == FULLDA) {
	 C0 = TCHILD4FDA(cp);
	 if (C0 == TRUE || C0 == FALSE)
	   { SLELTI(cp,TRUTH,C0); SLELTI(cp,HOWTV,BYPRP); goto Step8;}
	 goto Return; }
       /* End "G" quantifier. */

Step3: /* All true. */
       TCHILD(cp,&A1,&A0,&E1,&E0);
       if (A1)
         { SLELTI(cp,TRUTH,TRUE); SLELTI(cp,HOWTV,BYPRP); goto Step8; }

Step4: /* All false. */
       if (A0)
         { SLELTI(cp,TRUTH,FALSE); SLELTI(cp,HOWTV,BYPRP); goto Step8; }

Step5: /* At least one true, $Q_{k'+1} = \exists$. */
       q = LELTI(Q,kp + 1 - f);
       if (E1 && (q == EXIST))
         { SLELTI(cp,TRUTH,TRUE); SLELTI(cp,HOWTV,BYPRP); goto Step8; }

Step6: /* At least one false and $Q_{k'+1} = \forall$. */
       if (E0 && (q == UNIVER))
         { SLELTI(cp,TRUTH,FALSE); SLELTI(cp,HOWTV,BYPRP); goto Step8; }

Step7: /* Fail to propagate. */
       goto Return;

Step8: /* Prune. */
       SLELTI(cp,CHILD,NIL);
       kp = kp - 1;
       cp = DESCENDANT(D,LELTI(cp,INDX),kp);
       goto Step2;

Return: /* Prepare for return. */
       return;
}
